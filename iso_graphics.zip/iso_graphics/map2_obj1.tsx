<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="map2_obj1" tilewidth="1080" tileheight="1080" tilecount="1008" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="42" height="31" source="../graphics/lumeish - furniture pack/4.png"/>
 </tile>
 <tile id="1">
  <image width="34" height="35" source="../graphics/lumeish - furniture pack/5.png"/>
 </tile>
 <tile id="2">
  <image width="34" height="35" source="../graphics/lumeish - furniture pack/6.png"/>
 </tile>
 <tile id="3">
  <image width="31" height="29" source="../graphics/lumeish - furniture pack/7.png"/>
 </tile>
 <tile id="4">
  <image width="31" height="29" source="../graphics/lumeish - furniture pack/8.png"/>
 </tile>
 <tile id="5">
  <image width="28" height="27" source="../graphics/lumeish - furniture pack/9.png"/>
 </tile>
 <tile id="6">
  <image width="28" height="27" source="../graphics/lumeish - furniture pack/10.png"/>
 </tile>
 <tile id="7">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/11.png"/>
 </tile>
 <tile id="8">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/12.png"/>
 </tile>
 <tile id="9">
  <image width="30" height="26" source="../graphics/lumeish - furniture pack/13.png"/>
 </tile>
 <tile id="10">
  <image width="30" height="26" source="../graphics/lumeish - furniture pack/14.png"/>
 </tile>
 <tile id="11">
  <image width="28" height="28" source="../graphics/lumeish - furniture pack/15.png"/>
 </tile>
 <tile id="12">
  <image width="28" height="28" source="../graphics/lumeish - furniture pack/16.png"/>
 </tile>
 <tile id="13">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/17.png"/>
 </tile>
 <tile id="14">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/18.png"/>
 </tile>
 <tile id="15">
  <image width="26" height="29" source="../graphics/lumeish - furniture pack/19.png"/>
 </tile>
 <tile id="16">
  <image width="26" height="29" source="../graphics/lumeish - furniture pack/20.png"/>
 </tile>
 <tile id="17">
  <image width="26" height="19" source="../graphics/lumeish - furniture pack/21.png"/>
 </tile>
 <tile id="18">
  <image width="26" height="19" source="../graphics/lumeish - furniture pack/22.png"/>
 </tile>
 <tile id="19">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/23.png"/>
 </tile>
 <tile id="20">
  <image width="26" height="27" source="../graphics/lumeish - furniture pack/24.png"/>
 </tile>
 <tile id="21">
  <image width="27" height="24" source="../graphics/lumeish - furniture pack/25.png"/>
 </tile>
 <tile id="22">
  <image width="27" height="24" source="../graphics/lumeish - furniture pack/26.png"/>
 </tile>
 <tile id="23">
  <image width="26" height="20" source="../graphics/lumeish - furniture pack/27.png"/>
 </tile>
 <tile id="24">
  <image width="26" height="20" source="../graphics/lumeish - furniture pack/28.png"/>
 </tile>
 <tile id="25">
  <image width="18" height="15" source="../graphics/lumeish - furniture pack/29.png"/>
 </tile>
 <tile id="26">
  <image width="18" height="16" source="../graphics/lumeish - furniture pack/30.png"/>
 </tile>
 <tile id="27">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/31.png"/>
 </tile>
 <tile id="28">
  <image width="18" height="22" source="../graphics/lumeish - furniture pack/32.png"/>
 </tile>
 <tile id="29">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/33.png"/>
 </tile>
 <tile id="30">
  <image width="18" height="22" source="../graphics/lumeish - furniture pack/34.png"/>
 </tile>
 <tile id="31">
  <image width="22" height="28" source="../graphics/lumeish - furniture pack/35.png"/>
 </tile>
 <tile id="32">
  <image width="22" height="28" source="../graphics/lumeish - furniture pack/36.png"/>
 </tile>
 <tile id="33">
  <image width="18" height="23" source="../graphics/lumeish - furniture pack/37.png"/>
 </tile>
 <tile id="34">
  <image width="18" height="23" source="../graphics/lumeish - furniture pack/38.png"/>
 </tile>
 <tile id="35">
  <image width="18" height="22" source="../graphics/lumeish - furniture pack/39.png"/>
 </tile>
 <tile id="36">
  <image width="15" height="16" source="../graphics/lumeish - furniture pack/40.png"/>
 </tile>
 <tile id="37">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/41.png"/>
 </tile>
 <tile id="38">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/42.png"/>
 </tile>
 <tile id="39">
  <image width="17" height="17" source="../graphics/lumeish - furniture pack/43.png"/>
 </tile>
 <tile id="40">
  <image width="18" height="18" source="../graphics/lumeish - furniture pack/44.png"/>
 </tile>
 <tile id="41">
  <image width="32" height="46" source="../graphics/lumeish - furniture pack/45.png"/>
 </tile>
 <tile id="42">
  <image width="32" height="46" source="../graphics/lumeish - furniture pack/46.png"/>
 </tile>
 <tile id="43">
  <image width="30" height="30" source="../graphics/lumeish - furniture pack/47.png"/>
 </tile>
 <tile id="44">
  <image width="30" height="30" source="../graphics/lumeish - furniture pack/48.png"/>
 </tile>
 <tile id="45">
  <image width="36" height="33" source="../graphics/lumeish - furniture pack/49.png"/>
 </tile>
 <tile id="46">
  <image width="36" height="33" source="../graphics/lumeish - furniture pack/50.png"/>
 </tile>
 <tile id="47">
  <image width="26" height="33" source="../graphics/lumeish - furniture pack/51.png"/>
 </tile>
 <tile id="48">
  <image width="26" height="33" source="../graphics/lumeish - furniture pack/52.png"/>
 </tile>
 <tile id="49">
  <image width="26" height="33" source="../graphics/lumeish - furniture pack/53.png"/>
 </tile>
 <tile id="50">
  <image width="26" height="33" source="../graphics/lumeish - furniture pack/54.png"/>
 </tile>
 <tile id="51">
  <image width="26" height="29" source="../graphics/lumeish - furniture pack/55.png"/>
 </tile>
 <tile id="52">
  <image width="26" height="29" source="../graphics/lumeish - furniture pack/56.png"/>
 </tile>
 <tile id="53">
  <image width="42" height="45" source="../graphics/lumeish - furniture pack/57.png"/>
 </tile>
 <tile id="54">
  <image width="42" height="45" source="../graphics/lumeish - furniture pack/58.png"/>
 </tile>
 <tile id="55">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/59.png"/>
 </tile>
 <tile id="56">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/60.png"/>
 </tile>
 <tile id="57">
  <image width="26" height="38" source="../graphics/lumeish - furniture pack/61.png"/>
 </tile>
 <tile id="58">
  <image width="26" height="38" source="../graphics/lumeish - furniture pack/62.png"/>
 </tile>
 <tile id="59">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/63.png"/>
 </tile>
 <tile id="60">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/64.png"/>
 </tile>
 <tile id="61">
  <image width="22" height="12" source="../graphics/lumeish - furniture pack/65.png"/>
 </tile>
 <tile id="62">
  <image width="42" height="23" source="../graphics/lumeish - furniture pack/66.png"/>
 </tile>
 <tile id="63">
  <image width="22" height="34" source="../graphics/lumeish - furniture pack/67.png"/>
 </tile>
 <tile id="64">
  <image width="22" height="34" source="../graphics/lumeish - furniture pack/68.png"/>
 </tile>
 <tile id="65">
  <image width="18" height="33" source="../graphics/lumeish - furniture pack/69.png"/>
 </tile>
 <tile id="66">
  <image width="18" height="33" source="../graphics/lumeish - furniture pack/70.png"/>
 </tile>
 <tile id="67">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/71.png"/>
 </tile>
 <tile id="68">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/72.png"/>
 </tile>
 <tile id="69">
  <image width="34" height="25" source="../graphics/lumeish - furniture pack/73.png"/>
 </tile>
 <tile id="70">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/74.png"/>
 </tile>
 <tile id="71">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/75.png"/>
 </tile>
 <tile id="72">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/76.png"/>
 </tile>
 <tile id="73">
  <image width="42" height="29" source="../graphics/lumeish - furniture pack/77.png"/>
 </tile>
 <tile id="74">
  <image width="42" height="29" source="../graphics/lumeish - furniture pack/78.png"/>
 </tile>
 <tile id="75">
  <image width="30" height="21" source="../graphics/lumeish - furniture pack/79.png"/>
 </tile>
 <tile id="76">
  <image width="30" height="21" source="../graphics/lumeish - furniture pack/80.png"/>
 </tile>
 <tile id="77">
  <image width="26" height="39" source="../graphics/lumeish - furniture pack/81.png"/>
 </tile>
 <tile id="78">
  <image width="26" height="39" source="../graphics/lumeish - furniture pack/82.png"/>
 </tile>
 <tile id="79">
  <image width="26" height="23" source="../graphics/lumeish - furniture pack/83.png"/>
 </tile>
 <tile id="80">
  <image width="26" height="23" source="../graphics/lumeish - furniture pack/84.png"/>
 </tile>
 <tile id="81">
  <image width="20" height="34" source="../graphics/lumeish - furniture pack/85.png"/>
 </tile>
 <tile id="82">
  <image width="20" height="34" source="../graphics/lumeish - furniture pack/86.png"/>
 </tile>
 <tile id="83">
  <image width="20" height="34" source="../graphics/lumeish - furniture pack/87.png"/>
 </tile>
 <tile id="84">
  <image width="20" height="34" source="../graphics/lumeish - furniture pack/88.png"/>
 </tile>
 <tile id="85">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/89.png"/>
 </tile>
 <tile id="86">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/90.png"/>
 </tile>
 <tile id="87">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/91.png"/>
 </tile>
 <tile id="88">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/92.png"/>
 </tile>
 <tile id="89">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/93.png"/>
 </tile>
 <tile id="90">
  <image width="26" height="37" source="../graphics/lumeish - furniture pack/94.png"/>
 </tile>
 <tile id="91">
  <image width="7" height="8" source="../graphics/lumeish - furniture pack/95.png"/>
 </tile>
 <tile id="92">
  <image width="7" height="8" source="../graphics/lumeish - furniture pack/96.png"/>
 </tile>
 <tile id="93">
  <image width="43" height="33" source="../graphics/lumeish - furniture pack/97.png"/>
 </tile>
 <tile id="94">
  <image width="43" height="33" source="../graphics/lumeish - furniture pack/98.png"/>
 </tile>
 <tile id="95">
  <image width="20" height="25" source="../graphics/lumeish - furniture pack/99.png"/>
 </tile>
 <tile id="96">
  <image width="20" height="25" source="../graphics/lumeish - furniture pack/100.png"/>
 </tile>
 <tile id="97">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/101.png"/>
 </tile>
 <tile id="98">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/102.png"/>
 </tile>
 <tile id="99">
  <image width="12" height="22" source="../graphics/lumeish - furniture pack/103.png"/>
 </tile>
 <tile id="100">
  <image width="12" height="22" source="../graphics/lumeish - furniture pack/104.png"/>
 </tile>
 <tile id="101">
  <image width="16" height="16" source="../graphics/lumeish - furniture pack/105.png"/>
 </tile>
 <tile id="102">
  <image width="16" height="16" source="../graphics/lumeish - furniture pack/106.png"/>
 </tile>
 <tile id="103">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/107.png"/>
 </tile>
 <tile id="104">
  <image width="13" height="31" source="../graphics/lumeish - furniture pack/108.png"/>
 </tile>
 <tile id="105">
  <image width="34" height="26" source="../graphics/lumeish - furniture pack/109.png"/>
 </tile>
 <tile id="106">
  <image width="9" height="10" source="../graphics/lumeish - furniture pack/110.png"/>
 </tile>
 <tile id="107">
  <image width="32" height="25" source="../graphics/lumeish - furniture pack/111.png"/>
 </tile>
 <tile id="108">
  <image width="32" height="25" source="../graphics/lumeish - furniture pack/112.png"/>
 </tile>
 <tile id="109">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/113.png"/>
 </tile>
 <tile id="110">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/114.png"/>
 </tile>
 <tile id="111">
  <image width="24" height="16" source="../graphics/lumeish - furniture pack/115.png"/>
 </tile>
 <tile id="112">
  <image width="24" height="16" source="../graphics/lumeish - furniture pack/116.png"/>
 </tile>
 <tile id="113">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/117.png"/>
 </tile>
 <tile id="114">
  <image width="18" height="25" source="../graphics/lumeish - furniture pack/118.png"/>
 </tile>
 <tile id="115">
  <image width="18" height="35" source="../graphics/lumeish - furniture pack/119.png"/>
 </tile>
 <tile id="116">
  <image width="18" height="35" source="../graphics/lumeish - furniture pack/120.png"/>
 </tile>
 <tile id="117">
  <image width="28" height="18" source="../graphics/lumeish - furniture pack/121.png"/>
 </tile>
 <tile id="118">
  <image width="12" height="7" source="../graphics/lumeish - furniture pack/122.png"/>
 </tile>
 <tile id="119">
  <image width="17" height="29" source="../graphics/lumeish - furniture pack/123.png"/>
 </tile>
 <tile id="120">
  <image width="17" height="29" source="../graphics/lumeish - furniture pack/124.png"/>
 </tile>
 <tile id="121">
  <image width="14" height="16" source="../graphics/lumeish - furniture pack/125.png"/>
 </tile>
 <tile id="122">
  <image width="14" height="16" source="../graphics/lumeish - furniture pack/126.png"/>
 </tile>
 <tile id="123">
  <image width="18" height="24" source="../graphics/lumeish - furniture pack/127.png"/>
 </tile>
 <tile id="124">
  <image width="20" height="23" source="../graphics/lumeish - furniture pack/128.png"/>
 </tile>
 <tile id="125">
  <image width="26" height="23" source="../graphics/lumeish - furniture pack/129.png"/>
 </tile>
 <tile id="126">
  <image width="26" height="23" source="../graphics/lumeish - furniture pack/130.png"/>
 </tile>
 <tile id="127">
  <image width="22" height="13" source="../graphics/lumeish - furniture pack/131.png"/>
 </tile>
 <tile id="128">
  <image width="22" height="13" source="../graphics/lumeish - furniture pack/132.png"/>
 </tile>
 <tile id="129">
  <image width="10" height="10" source="../graphics/lumeish - furniture pack/133.png"/>
 </tile>
 <tile id="130">
  <image width="10" height="10" source="../graphics/lumeish - furniture pack/134.png"/>
 </tile>
 <tile id="131">
  <image width="14" height="9" source="../graphics/lumeish - furniture pack/135.png"/>
 </tile>
 <tile id="132">
  <image width="14" height="9" source="../graphics/lumeish - furniture pack/136.png"/>
 </tile>
 <tile id="133">
  <image width="22" height="13" source="../graphics/lumeish - furniture pack/137.png"/>
 </tile>
 <tile id="134">
  <image width="22" height="13" source="../graphics/lumeish - furniture pack/138.png"/>
 </tile>
 <tile id="135">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/139.png"/>
 </tile>
 <tile id="136">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/140.png"/>
 </tile>
 <tile id="137">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/141.png"/>
 </tile>
 <tile id="138">
  <image width="26" height="21" source="../graphics/lumeish - furniture pack/142.png"/>
 </tile>
 <tile id="139">
  <image width="28" height="22" source="../graphics/lumeish - furniture pack/143.png"/>
 </tile>
 <tile id="140">
  <image width="28" height="22" source="../graphics/lumeish - furniture pack/144.png"/>
 </tile>
 <tile id="141">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/145.png"/>
 </tile>
 <tile id="142">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/146.png"/>
 </tile>
 <tile id="143">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/147.png"/>
 </tile>
 <tile id="144">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/148.png"/>
 </tile>
 <tile id="145">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/149.png"/>
 </tile>
 <tile id="146">
  <image width="18" height="17" source="../graphics/lumeish - furniture pack/150.png"/>
 </tile>
 <tile id="147">
  <image width="98" height="84" source="../graphics/lumeish - furniture pack/151.png"/>
 </tile>
 <tile id="148">
  <image width="576" height="800" source="../graphics/lumeish - furniture pack/all_furniture.png"/>
 </tile>
 <tile id="149">
  <image width="37" height="32" source="../graphics/lumeish - furniture pack/1.png"/>
 </tile>
 <tile id="150">
  <image width="37" height="32" source="../graphics/lumeish - furniture pack/2.png"/>
 </tile>
 <tile id="151">
  <image width="42" height="31" source="../graphics/lumeish - furniture pack/3.png"/>
 </tile>
 <tile id="152">
  <image width="79" height="154" source="../graphics/kenney_furniturePack/Isometric/wallWindowSlide_NW.png"/>
 </tile>
 <tile id="153">
  <image width="80" height="153" source="../graphics/kenney_furniturePack/Isometric/wallWindowSlide_SE.png"/>
 </tile>
 <tile id="154">
  <image width="80" height="154" source="../graphics/kenney_furniturePack/Isometric/wallWindowSlide_SW.png"/>
 </tile>
 <tile id="155">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/washer_NE.png"/>
 </tile>
 <tile id="156">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/washer_NW.png"/>
 </tile>
 <tile id="157">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/washer_SE.png"/>
 </tile>
 <tile id="158">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/washer_SW.png"/>
 </tile>
 <tile id="159">
  <image width="56" height="110" source="../graphics/kenney_furniturePack/Isometric/washerDryerStacked_NE.png"/>
 </tile>
 <tile id="160">
  <image width="56" height="110" source="../graphics/kenney_furniturePack/Isometric/washerDryerStacked_NW.png"/>
 </tile>
 <tile id="161">
  <image width="56" height="109" source="../graphics/kenney_furniturePack/Isometric/washerDryerStacked_SE.png"/>
 </tile>
 <tile id="162">
  <image width="56" height="109" source="../graphics/kenney_furniturePack/Isometric/washerDryerStacked_SW.png"/>
 </tile>
 <tile id="163">
  <image width="27" height="49" source="../graphics/kenney_furniturePack/Isometric/bathroomCabinet_NE.png"/>
 </tile>
 <tile id="164">
  <image width="27" height="49" source="../graphics/kenney_furniturePack/Isometric/bathroomCabinet_NW.png"/>
 </tile>
 <tile id="165">
  <image width="28" height="49" source="../graphics/kenney_furniturePack/Isometric/bathroomCabinet_SE.png"/>
 </tile>
 <tile id="166">
  <image width="28" height="49" source="../graphics/kenney_furniturePack/Isometric/bathroomCabinet_SW.png"/>
 </tile>
 <tile id="167">
  <image width="34" height="48" source="../graphics/kenney_furniturePack/Isometric/bathroomMirror_NE.png"/>
 </tile>
 <tile id="168">
  <image width="34" height="48" source="../graphics/kenney_furniturePack/Isometric/bathroomMirror_NW.png"/>
 </tile>
 <tile id="169">
  <image width="34" height="53" source="../graphics/kenney_furniturePack/Isometric/bathroomMirror_SE.png"/>
 </tile>
 <tile id="170">
  <image width="34" height="53" source="../graphics/kenney_furniturePack/Isometric/bathroomMirror_SW.png"/>
 </tile>
 <tile id="171">
  <image width="42" height="63" source="../graphics/kenney_furniturePack/Isometric/bathroomSink_NE.png"/>
 </tile>
 <tile id="172">
  <image width="42" height="63" source="../graphics/kenney_furniturePack/Isometric/bathroomSink_NW.png"/>
 </tile>
 <tile id="173">
  <image width="43" height="59" source="../graphics/kenney_furniturePack/Isometric/bathroomSink_SE.png"/>
 </tile>
 <tile id="174">
  <image width="43" height="59" source="../graphics/kenney_furniturePack/Isometric/bathroomSink_SW.png"/>
 </tile>
 <tile id="175">
  <image width="129" height="119" source="../graphics/kenney_furniturePack/Isometric/bathtub_NE.png"/>
 </tile>
 <tile id="176">
  <image width="130" height="118" source="../graphics/kenney_furniturePack/Isometric/bathtub_NW.png"/>
 </tile>
 <tile id="177">
  <image width="130" height="118" source="../graphics/kenney_furniturePack/Isometric/bathtub_SE.png"/>
 </tile>
 <tile id="178">
  <image width="130" height="118" source="../graphics/kenney_furniturePack/Isometric/bathtub_SW.png"/>
 </tile>
 <tile id="179">
  <image width="37" height="41" source="../graphics/kenney_furniturePack/Isometric/bear_NE.png"/>
 </tile>
 <tile id="180">
  <image width="37" height="41" source="../graphics/kenney_furniturePack/Isometric/bear_NW.png"/>
 </tile>
 <tile id="181">
  <image width="38" height="39" source="../graphics/kenney_furniturePack/Isometric/bear_SE.png"/>
 </tile>
 <tile id="182">
  <image width="38" height="40" source="../graphics/kenney_furniturePack/Isometric/bear_SW.png"/>
 </tile>
 <tile id="183">
  <image width="126" height="153" source="../graphics/kenney_furniturePack/Isometric/bedBunk_NE.png"/>
 </tile>
 <tile id="184">
  <image width="125" height="152" source="../graphics/kenney_furniturePack/Isometric/bedBunk_NW.png"/>
 </tile>
 <tile id="185">
  <image width="125" height="153" source="../graphics/kenney_furniturePack/Isometric/bedBunk_SE.png"/>
 </tile>
 <tile id="186">
  <image width="126" height="153" source="../graphics/kenney_furniturePack/Isometric/bedBunk_SW.png"/>
 </tile>
 <tile id="187">
  <image width="157" height="126" source="../graphics/kenney_furniturePack/Isometric/bedDouble_NE.png"/>
 </tile>
 <tile id="188">
  <image width="157" height="126" source="../graphics/kenney_furniturePack/Isometric/bedDouble_NW.png"/>
 </tile>
 <tile id="189">
  <image width="157" height="138" source="../graphics/kenney_furniturePack/Isometric/bedDouble_SE.png"/>
 </tile>
 <tile id="190">
  <image width="157" height="138" source="../graphics/kenney_furniturePack/Isometric/bedDouble_SW.png"/>
 </tile>
 <tile id="191">
  <image width="128" height="105" source="../graphics/kenney_furniturePack/Isometric/bedSingle_NE.png"/>
 </tile>
 <tile id="192">
  <image width="128" height="105" source="../graphics/kenney_furniturePack/Isometric/bedSingle_NW.png"/>
 </tile>
 <tile id="193">
  <image width="128" height="118" source="../graphics/kenney_furniturePack/Isometric/bedSingle_SE.png"/>
 </tile>
 <tile id="194">
  <image width="128" height="118" source="../graphics/kenney_furniturePack/Isometric/bedSingle_SW.png"/>
 </tile>
 <tile id="195">
  <image width="46" height="59" source="../graphics/kenney_furniturePack/Isometric/bench_NE.png"/>
 </tile>
 <tile id="196">
  <image width="45" height="59" source="../graphics/kenney_furniturePack/Isometric/bench_NW.png"/>
 </tile>
 <tile id="197">
  <image width="46" height="67" source="../graphics/kenney_furniturePack/Isometric/bench_SE.png"/>
 </tile>
 <tile id="198">
  <image width="46" height="67" source="../graphics/kenney_furniturePack/Isometric/bench_SW.png"/>
 </tile>
 <tile id="199">
  <image width="46" height="58" source="../graphics/kenney_furniturePack/Isometric/benchCushion_NE.png"/>
 </tile>
 <tile id="200">
  <image width="45" height="58" source="../graphics/kenney_furniturePack/Isometric/benchCushion_NW.png"/>
 </tile>
 <tile id="201">
  <image width="46" height="67" source="../graphics/kenney_furniturePack/Isometric/benchCushion_SE.png"/>
 </tile>
 <tile id="202">
  <image width="46" height="66" source="../graphics/kenney_furniturePack/Isometric/benchCushion_SW.png"/>
 </tile>
 <tile id="203">
  <image width="49" height="48" source="../graphics/kenney_furniturePack/Isometric/benchCushionLow_NE.png"/>
 </tile>
 <tile id="204">
  <image width="49" height="48" source="../graphics/kenney_furniturePack/Isometric/benchCushionLow_NW.png"/>
 </tile>
 <tile id="205">
  <image width="49" height="48" source="../graphics/kenney_furniturePack/Isometric/benchCushionLow_SE.png"/>
 </tile>
 <tile id="206">
  <image width="48" height="48" source="../graphics/kenney_furniturePack/Isometric/benchCushionLow_SW.png"/>
 </tile>
 <tile id="207">
  <image width="49" height="99" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosed_NE.png"/>
 </tile>
 <tile id="208">
  <image width="49" height="98" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosed_NW.png"/>
 </tile>
 <tile id="209">
  <image width="50" height="99" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosed_SE.png"/>
 </tile>
 <tile id="210">
  <image width="49" height="98" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosed_SW.png"/>
 </tile>
 <tile id="211">
  <image width="49" height="99" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedDoors_NE.png"/>
 </tile>
 <tile id="212">
  <image width="49" height="98" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedDoors_NW.png"/>
 </tile>
 <tile id="213">
  <image width="50" height="99" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedDoors_SE.png"/>
 </tile>
 <tile id="214">
  <image width="49" height="98" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedDoors_SW.png"/>
 </tile>
 <tile id="215">
  <image width="79" height="116" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedWide_NE.png"/>
 </tile>
 <tile id="216">
  <image width="79" height="115" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedWide_NW.png"/>
 </tile>
 <tile id="217">
  <image width="80" height="115" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedWide_SE.png"/>
 </tile>
 <tile id="218">
  <image width="80" height="116" source="../graphics/kenney_furniturePack/Isometric/bookcaseClosedWide_SW.png"/>
 </tile>
 <tile id="219">
  <image width="49" height="101" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpen_NE.png"/>
 </tile>
 <tile id="220">
  <image width="49" height="101" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpen_NW.png"/>
 </tile>
 <tile id="221">
  <image width="50" height="101" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpen_SE.png"/>
 </tile>
 <tile id="222">
  <image width="49" height="101" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpen_SW.png"/>
 </tile>
 <tile id="223">
  <image width="49" height="65" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpenLow_NE.png"/>
 </tile>
 <tile id="224">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpenLow_NW.png"/>
 </tile>
 <tile id="225">
  <image width="50" height="65" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpenLow_SE.png"/>
 </tile>
 <tile id="226">
  <image width="49" height="65" source="../graphics/kenney_furniturePack/Isometric/bookcaseOpenLow_SW.png"/>
 </tile>
 <tile id="227">
  <image width="18" height="19" source="../graphics/kenney_furniturePack/Isometric/books_NE.png"/>
 </tile>
 <tile id="228">
  <image width="17" height="20" source="../graphics/kenney_furniturePack/Isometric/books_NW.png"/>
 </tile>
 <tile id="229">
  <image width="19" height="19" source="../graphics/kenney_furniturePack/Isometric/books_SE.png"/>
 </tile>
 <tile id="230">
  <image width="18" height="20" source="../graphics/kenney_furniturePack/Isometric/books_SW.png"/>
 </tile>
 <tile id="231">
  <image width="37" height="43" source="../graphics/kenney_furniturePack/Isometric/cabinetBed_NE.png"/>
 </tile>
 <tile id="232">
  <image width="37" height="43" source="../graphics/kenney_furniturePack/Isometric/cabinetBed_NW.png"/>
 </tile>
 <tile id="233">
  <image width="37" height="42" source="../graphics/kenney_furniturePack/Isometric/cabinetBed_SE.png"/>
 </tile>
 <tile id="234">
  <image width="36" height="42" source="../graphics/kenney_furniturePack/Isometric/cabinetBed_SW.png"/>
 </tile>
 <tile id="235">
  <image width="37" height="45" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawer_NE.png"/>
 </tile>
 <tile id="236">
  <image width="37" height="45" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawer_NW.png"/>
 </tile>
 <tile id="237">
  <image width="37" height="44" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawer_SE.png"/>
 </tile>
 <tile id="238">
  <image width="36" height="44" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawer_SW.png"/>
 </tile>
 <tile id="239">
  <image width="37" height="45" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawerTable_NE.png"/>
 </tile>
 <tile id="240">
  <image width="37" height="45" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawerTable_NW.png"/>
 </tile>
 <tile id="241">
  <image width="37" height="44" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawerTable_SE.png"/>
 </tile>
 <tile id="242">
  <image width="36" height="44" source="../graphics/kenney_furniturePack/Isometric/cabinetBedDrawerTable_SW.png"/>
 </tile>
 <tile id="243">
  <image width="79" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevision_NE.png"/>
 </tile>
 <tile id="244">
  <image width="79" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevision_NW.png"/>
 </tile>
 <tile id="245">
  <image width="80" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevision_SE.png"/>
 </tile>
 <tile id="246">
  <image width="80" height="80" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevision_SW.png"/>
 </tile>
 <tile id="247">
  <image width="79" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevisionDoors_NE.png"/>
 </tile>
 <tile id="248">
  <image width="79" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevisionDoors_NW.png"/>
 </tile>
 <tile id="249">
  <image width="80" height="79" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevisionDoors_SE.png"/>
 </tile>
 <tile id="250">
  <image width="80" height="80" source="../graphics/kenney_furniturePack/Isometric/cabinetTelevisionDoors_SW.png"/>
 </tile>
 <tile id="251">
  <image width="32" height="40" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxClosed_NE.png"/>
 </tile>
 <tile id="252">
  <image width="32" height="40" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxClosed_NW.png"/>
 </tile>
 <tile id="253">
  <image width="32" height="39" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxClosed_SE.png"/>
 </tile>
 <tile id="254">
  <image width="33" height="40" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxClosed_SW.png"/>
 </tile>
 <tile id="255">
  <image width="45" height="48" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxOpen_NE.png"/>
 </tile>
 <tile id="256">
  <image width="44" height="49" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxOpen_NW.png"/>
 </tile>
 <tile id="257">
  <image width="44" height="48" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxOpen_SE.png"/>
 </tile>
 <tile id="258">
  <image width="44" height="49" source="../graphics/kenney_furniturePack/Isometric/cardboardBoxOpen_SW.png"/>
 </tile>
 <tile id="259">
  <image width="55" height="39" source="../graphics/kenney_furniturePack/Isometric/ceilingFan_NE.png"/>
 </tile>
 <tile id="260">
  <image width="54" height="40" source="../graphics/kenney_furniturePack/Isometric/ceilingFan_NW.png"/>
 </tile>
 <tile id="261">
  <image width="54" height="40" source="../graphics/kenney_furniturePack/Isometric/ceilingFan_SE.png"/>
 </tile>
 <tile id="262">
  <image width="55" height="39" source="../graphics/kenney_furniturePack/Isometric/ceilingFan_SW.png"/>
 </tile>
 <tile id="263">
  <image width="31" height="49" source="../graphics/kenney_furniturePack/Isometric/chair_NE.png"/>
 </tile>
 <tile id="264">
  <image width="30" height="49" source="../graphics/kenney_furniturePack/Isometric/chair_NW.png"/>
 </tile>
 <tile id="265">
  <image width="31" height="57" source="../graphics/kenney_furniturePack/Isometric/chair_SE.png"/>
 </tile>
 <tile id="266">
  <image width="31" height="57" source="../graphics/kenney_furniturePack/Isometric/chair_SW.png"/>
 </tile>
 <tile id="267">
  <image width="31" height="48" source="../graphics/kenney_furniturePack/Isometric/chairCushion_NE.png"/>
 </tile>
 <tile id="268">
  <image width="30" height="48" source="../graphics/kenney_furniturePack/Isometric/chairCushion_NW.png"/>
 </tile>
 <tile id="269">
  <image width="31" height="56" source="../graphics/kenney_furniturePack/Isometric/chairCushion_SE.png"/>
 </tile>
 <tile id="270">
  <image width="31" height="56" source="../graphics/kenney_furniturePack/Isometric/chairCushion_SW.png"/>
 </tile>
 <tile id="271">
  <image width="44" height="56" source="../graphics/kenney_furniturePack/Isometric/chairDesk_NE.png"/>
 </tile>
 <tile id="272">
  <image width="44" height="56" source="../graphics/kenney_furniturePack/Isometric/chairDesk_NW.png"/>
 </tile>
 <tile id="273">
  <image width="44" height="71" source="../graphics/kenney_furniturePack/Isometric/chairDesk_SE.png"/>
 </tile>
 <tile id="274">
  <image width="45" height="70" source="../graphics/kenney_furniturePack/Isometric/chairDesk_SW.png"/>
 </tile>
 <tile id="275">
  <image width="31" height="44" source="../graphics/kenney_furniturePack/Isometric/chairRounded_NE.png"/>
 </tile>
 <tile id="276">
  <image width="30" height="44" source="../graphics/kenney_furniturePack/Isometric/chairRounded_NW.png"/>
 </tile>
 <tile id="277">
  <image width="31" height="52" source="../graphics/kenney_furniturePack/Isometric/chairRounded_SE.png"/>
 </tile>
 <tile id="278">
  <image width="31" height="52" source="../graphics/kenney_furniturePack/Isometric/chairRounded_SW.png"/>
 </tile>
 <tile id="279">
  <image width="45" height="48" source="../graphics/kenney_furniturePack/Isometric/coatRack_NE.png"/>
 </tile>
 <tile id="280">
  <image width="44" height="49" source="../graphics/kenney_furniturePack/Isometric/coatRack_NW.png"/>
 </tile>
 <tile id="281">
  <image width="44" height="46" source="../graphics/kenney_furniturePack/Isometric/coatRack_SE.png"/>
 </tile>
 <tile id="282">
  <image width="44" height="46" source="../graphics/kenney_furniturePack/Isometric/coatRack_SW.png"/>
 </tile>
 <tile id="283">
  <image width="24" height="73" source="../graphics/kenney_furniturePack/Isometric/coatRackStanding_NE.png"/>
 </tile>
 <tile id="284">
  <image width="24" height="73" source="../graphics/kenney_furniturePack/Isometric/coatRackStanding_NW.png"/>
 </tile>
 <tile id="285">
  <image width="24" height="73" source="../graphics/kenney_furniturePack/Isometric/coatRackStanding_SE.png"/>
 </tile>
 <tile id="286">
  <image width="24" height="73" source="../graphics/kenney_furniturePack/Isometric/coatRackStanding_SW.png"/>
 </tile>
 <tile id="287">
  <image width="30" height="23" source="../graphics/kenney_furniturePack/Isometric/computerKeyboard_NE.png"/>
 </tile>
 <tile id="288">
  <image width="30" height="22" source="../graphics/kenney_furniturePack/Isometric/computerKeyboard_NW.png"/>
 </tile>
 <tile id="289">
  <image width="31" height="23" source="../graphics/kenney_furniturePack/Isometric/computerKeyboard_SE.png"/>
 </tile>
 <tile id="290">
  <image width="31" height="23" source="../graphics/kenney_furniturePack/Isometric/computerKeyboard_SW.png"/>
 </tile>
 <tile id="291">
  <image width="9" height="6" source="../graphics/kenney_furniturePack/Isometric/computerMouse_NE.png"/>
 </tile>
 <tile id="292">
  <image width="8" height="6" source="../graphics/kenney_furniturePack/Isometric/computerMouse_NW.png"/>
 </tile>
 <tile id="293">
  <image width="8" height="8" source="../graphics/kenney_furniturePack/Isometric/computerMouse_SE.png"/>
 </tile>
 <tile id="294">
  <image width="9" height="8" source="../graphics/kenney_furniturePack/Isometric/computerMouse_SW.png"/>
 </tile>
 <tile id="295">
  <image width="34" height="40" source="../graphics/kenney_furniturePack/Isometric/computerScreen_NE.png"/>
 </tile>
 <tile id="296">
  <image width="34" height="40" source="../graphics/kenney_furniturePack/Isometric/computerScreen_NW.png"/>
 </tile>
 <tile id="297">
  <image width="35" height="43" source="../graphics/kenney_furniturePack/Isometric/computerScreen_SE.png"/>
 </tile>
 <tile id="298">
  <image width="35" height="43" source="../graphics/kenney_furniturePack/Isometric/computerScreen_SW.png"/>
 </tile>
 <tile id="299">
  <image width="85" height="88" source="../graphics/kenney_furniturePack/Isometric/desk_NE.png"/>
 </tile>
 <tile id="300">
  <image width="85" height="88" source="../graphics/kenney_furniturePack/Isometric/desk_NW.png"/>
 </tile>
 <tile id="301">
  <image width="85" height="88" source="../graphics/kenney_furniturePack/Isometric/desk_SE.png"/>
 </tile>
 <tile id="302">
  <image width="85" height="88" source="../graphics/kenney_furniturePack/Isometric/desk_SW.png"/>
 </tile>
 <tile id="303">
  <image width="147" height="101" source="../graphics/kenney_furniturePack/Isometric/deskCorner_NE.png"/>
 </tile>
 <tile id="304">
  <image width="103" height="132" source="../graphics/kenney_furniturePack/Isometric/deskCorner_NW.png"/>
 </tile>
 <tile id="305">
  <image width="147" height="101" source="../graphics/kenney_furniturePack/Isometric/deskCorner_SE.png"/>
 </tile>
 <tile id="306">
  <image width="103" height="132" source="../graphics/kenney_furniturePack/Isometric/deskCorner_SW.png"/>
 </tile>
 <tile id="307">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorway_NE.png"/>
 </tile>
 <tile id="308">
  <image width="43" height="107" source="../graphics/kenney_furniturePack/Isometric/doorway_NW.png"/>
 </tile>
 <tile id="309">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorway_SE.png"/>
 </tile>
 <tile id="310">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorway_SW.png"/>
 </tile>
 <tile id="311">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_NE.png"/>
 </tile>
 <tile id="312">
  <image width="43" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_NW.png"/>
 </tile>
 <tile id="313">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_SE.png"/>
 </tile>
 <tile id="314">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_SW.png"/>
 </tile>
 <tile id="315">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayOpen_NE.png"/>
 </tile>
 <tile id="316">
  <image width="43" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayOpen_NW.png"/>
 </tile>
 <tile id="317">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayOpen_SE.png"/>
 </tile>
 <tile id="318">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayOpen_SW.png"/>
 </tile>
 <tile id="319">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/dryer_NE.png"/>
 </tile>
 <tile id="320">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/dryer_NW.png"/>
 </tile>
 <tile id="321">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/dryer_SE.png"/>
 </tile>
 <tile id="322">
  <image width="56" height="74" source="../graphics/kenney_furniturePack/Isometric/dryer_SW.png"/>
 </tile>
 <tile id="323">
  <image width="76" height="63" source="../graphics/kenney_furniturePack/Isometric/floorCorner_NE.png"/>
 </tile>
 <tile id="324">
  <image width="83" height="58" source="../graphics/kenney_furniturePack/Isometric/floorCorner_NW.png"/>
 </tile>
 <tile id="325">
  <image width="75" height="62" source="../graphics/kenney_furniturePack/Isometric/floorCorner_SE.png"/>
 </tile>
 <tile id="326">
  <image width="83" height="57" source="../graphics/kenney_furniturePack/Isometric/floorCorner_SW.png"/>
 </tile>
 <tile id="327">
  <image width="79" height="63" source="../graphics/kenney_furniturePack/Isometric/floorCornerRound_NE.png"/>
 </tile>
 <tile id="328">
  <image width="83" height="60" source="../graphics/kenney_furniturePack/Isometric/floorCornerRound_NW.png"/>
 </tile>
 <tile id="329">
  <image width="79" height="62" source="../graphics/kenney_furniturePack/Isometric/floorCornerRound_SE.png"/>
 </tile>
 <tile id="330">
  <image width="83" height="60" source="../graphics/kenney_furniturePack/Isometric/floorCornerRound_SW.png"/>
 </tile>
 <tile id="331">
  <image width="151" height="111" source="../graphics/kenney_furniturePack/Isometric/floorFull_NE.png"/>
 </tile>
 <tile id="332">
  <image width="151" height="111" source="../graphics/kenney_furniturePack/Isometric/floorFull_NW.png"/>
 </tile>
 <tile id="333">
  <image width="151" height="110" source="../graphics/kenney_furniturePack/Isometric/floorFull_SE.png"/>
 </tile>
 <tile id="334">
  <image width="151" height="111" source="../graphics/kenney_furniturePack/Isometric/floorFull_SW.png"/>
 </tile>
 <tile id="335">
  <image width="114" height="84" source="../graphics/kenney_furniturePack/Isometric/floorHalf_NE.png"/>
 </tile>
 <tile id="336">
  <image width="113" height="84" source="../graphics/kenney_furniturePack/Isometric/floorHalf_NW.png"/>
 </tile>
 <tile id="337">
  <image width="113" height="84" source="../graphics/kenney_furniturePack/Isometric/floorHalf_SE.png"/>
 </tile>
 <tile id="338">
  <image width="114" height="84" source="../graphics/kenney_furniturePack/Isometric/floorHalf_SW.png"/>
 </tile>
 <tile id="339">
  <image width="48" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenBar_NE.png"/>
 </tile>
 <tile id="340">
  <image width="48" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenBar_NW.png"/>
 </tile>
 <tile id="341">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenBar_SE.png"/>
 </tile>
 <tile id="342">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenBar_SW.png"/>
 </tile>
 <tile id="343">
  <image width="20" height="44" source="../graphics/kenney_furniturePack/Isometric/kitchenBarEnd_NE.png"/>
 </tile>
 <tile id="344">
  <image width="19" height="42" source="../graphics/kenney_furniturePack/Isometric/kitchenBarEnd_NW.png"/>
 </tile>
 <tile id="345">
  <image width="19" height="42" source="../graphics/kenney_furniturePack/Isometric/kitchenBarEnd_SE.png"/>
 </tile>
 <tile id="346">
  <image width="19" height="44" source="../graphics/kenney_furniturePack/Isometric/kitchenBarEnd_SW.png"/>
 </tile>
 <tile id="347">
  <image width="13" height="25" source="../graphics/kenney_furniturePack/Isometric/kitchenBlender_NE.png"/>
 </tile>
 <tile id="348">
  <image width="13" height="25" source="../graphics/kenney_furniturePack/Isometric/kitchenBlender_NW.png"/>
 </tile>
 <tile id="349">
  <image width="12" height="24" source="../graphics/kenney_furniturePack/Isometric/kitchenBlender_SE.png"/>
 </tile>
 <tile id="350">
  <image width="12" height="25" source="../graphics/kenney_furniturePack/Isometric/kitchenBlender_SW.png"/>
 </tile>
 <tile id="351">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinet_NE.png"/>
 </tile>
 <tile id="352">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinet_NW.png"/>
 </tile>
 <tile id="353">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinet_SE.png"/>
 </tile>
 <tile id="354">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinet_SW.png"/>
 </tile>
 <tile id="355">
  <image width="70" height="80" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerInner_NE.png"/>
 </tile>
 <tile id="356">
  <image width="69" height="83" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerInner_NW.png"/>
 </tile>
 <tile id="357">
  <image width="70" height="81" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerInner_SE.png"/>
 </tile>
 <tile id="358">
  <image width="69" height="83" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerInner_SW.png"/>
 </tile>
 <tile id="359">
  <image width="68" height="69" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerRound_NE.png"/>
 </tile>
 <tile id="360">
  <image width="54" height="78" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerRound_NW.png"/>
 </tile>
 <tile id="361">
  <image width="68" height="69" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerRound_SE.png"/>
 </tile>
 <tile id="362">
  <image width="53" height="78" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetCornerRound_SW.png"/>
 </tile>
 <tile id="363">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer 1_NE.png"/>
 </tile>
 <tile id="364">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer 1_NW.png"/>
 </tile>
 <tile id="365">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer 1_SE.png"/>
 </tile>
 <tile id="366">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer 1_SW.png"/>
 </tile>
 <tile id="367">
  <image width="55" height="70" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer_NE.png"/>
 </tile>
 <tile id="368">
  <image width="55" height="70" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer_NW.png"/>
 </tile>
 <tile id="369">
  <image width="56" height="70" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer_SE.png"/>
 </tile>
 <tile id="370">
  <image width="56" height="70" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetDrawer_SW.png"/>
 </tile>
 <tile id="371">
  <image width="48" height="63" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpper_NE.png"/>
 </tile>
 <tile id="372">
  <image width="48" height="63" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpper_NW.png"/>
 </tile>
 <tile id="373">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpper_SE.png"/>
 </tile>
 <tile id="374">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpper_SW.png"/>
 </tile>
 <tile id="375">
  <image width="32" height="50" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperCorner_NE.png"/>
 </tile>
 <tile id="376">
  <image width="29" height="52" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperCorner_NW.png"/>
 </tile>
 <tile id="377">
  <image width="33" height="50" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperCorner_SE.png"/>
 </tile>
 <tile id="378">
  <image width="29" height="53" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperCorner_SW.png"/>
 </tile>
 <tile id="379">
  <image width="48" height="63" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperDouble_NE.png"/>
 </tile>
 <tile id="380">
  <image width="48" height="63" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperDouble_NW.png"/>
 </tile>
 <tile id="381">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperDouble_SE.png"/>
 </tile>
 <tile id="382">
  <image width="49" height="64" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperDouble_SW.png"/>
 </tile>
 <tile id="383">
  <image width="48" height="49" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperLow_NE.png"/>
 </tile>
 <tile id="384">
  <image width="48" height="49" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperLow_NW.png"/>
 </tile>
 <tile id="385">
  <image width="49" height="49" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperLow_SE.png"/>
 </tile>
 <tile id="386">
  <image width="49" height="49" source="../graphics/kenney_furniturePack/Isometric/kitchenCabinetUpperLow_SW.png"/>
 </tile>
 <tile id="387">
  <image width="26" height="27" source="../graphics/kenney_furniturePack/Isometric/kitchenCoffeeMachine_NE.png"/>
 </tile>
 <tile id="388">
  <image width="26" height="27" source="../graphics/kenney_furniturePack/Isometric/kitchenCoffeeMachine_NW.png"/>
 </tile>
 <tile id="389">
  <image width="26" height="32" source="../graphics/kenney_furniturePack/Isometric/kitchenCoffeeMachine_SE.png"/>
 </tile>
 <tile id="390">
  <image width="25" height="32" source="../graphics/kenney_furniturePack/Isometric/kitchenCoffeeMachine_SW.png"/>
 </tile>
 <tile id="391">
  <image width="53" height="106" source="../graphics/kenney_furniturePack/Isometric/kitchenFridge_NE.png"/>
 </tile>
 <tile id="392">
  <image width="53" height="106" source="../graphics/kenney_furniturePack/Isometric/kitchenFridge_NW.png"/>
 </tile>
 <tile id="393">
  <image width="52" height="105" source="../graphics/kenney_furniturePack/Isometric/kitchenFridge_SE.png"/>
 </tile>
 <tile id="394">
  <image width="52" height="105" source="../graphics/kenney_furniturePack/Isometric/kitchenFridge_SW.png"/>
 </tile>
 <tile id="395">
  <image width="65" height="111" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeBuiltIn_NE.png"/>
 </tile>
 <tile id="396">
  <image width="65" height="111" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeBuiltIn_NW.png"/>
 </tile>
 <tile id="397">
  <image width="65" height="110" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeBuiltIn_SE.png"/>
 </tile>
 <tile id="398">
  <image width="65" height="111" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeBuiltIn_SW.png"/>
 </tile>
 <tile id="399">
  <image width="53" height="82" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeSmall_NE.png"/>
 </tile>
 <tile id="400">
  <image width="53" height="82" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeSmall_NW.png"/>
 </tile>
 <tile id="401">
  <image width="52" height="81" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeSmall_SE.png"/>
 </tile>
 <tile id="402">
  <image width="52" height="81" source="../graphics/kenney_furniturePack/Isometric/kitchenFridgeSmall_SW.png"/>
 </tile>
 <tile id="403">
  <image width="37" height="40" source="../graphics/kenney_furniturePack/Isometric/kitchenMicrowave_NE.png"/>
 </tile>
 <tile id="404">
  <image width="37" height="39" source="../graphics/kenney_furniturePack/Isometric/kitchenMicrowave_NW.png"/>
 </tile>
 <tile id="405">
  <image width="37" height="40" source="../graphics/kenney_furniturePack/Isometric/kitchenMicrowave_SE.png"/>
 </tile>
 <tile id="406">
  <image width="37" height="39" source="../graphics/kenney_furniturePack/Isometric/kitchenMicrowave_SW.png"/>
 </tile>
 <tile id="407">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenSink_NE.png"/>
 </tile>
 <tile id="408">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenSink_NW.png"/>
 </tile>
 <tile id="409">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenSink_SE.png"/>
 </tile>
 <tile id="410">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenSink_SW.png"/>
 </tile>
 <tile id="411">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStove_NE.png"/>
 </tile>
 <tile id="412">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStove_NW.png"/>
 </tile>
 <tile id="413">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStove_SE.png"/>
 </tile>
 <tile id="414">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStove_SW.png"/>
 </tile>
 <tile id="415">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStoveElectric_NE.png"/>
 </tile>
 <tile id="416">
  <image width="66" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStoveElectric_NW.png"/>
 </tile>
 <tile id="417">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStoveElectric_SE.png"/>
 </tile>
 <tile id="418">
  <image width="67" height="79" source="../graphics/kenney_furniturePack/Isometric/kitchenStoveElectric_SW.png"/>
 </tile>
 <tile id="419">
  <image width="19" height="76" source="../graphics/kenney_furniturePack/Isometric/lampRoundFloor_NE.png"/>
 </tile>
 <tile id="420">
  <image width="18" height="76" source="../graphics/kenney_furniturePack/Isometric/lampRoundFloor_NW.png"/>
 </tile>
 <tile id="421">
  <image width="19" height="76" source="../graphics/kenney_furniturePack/Isometric/lampRoundFloor_SE.png"/>
 </tile>
 <tile id="422">
  <image width="19" height="76" source="../graphics/kenney_furniturePack/Isometric/lampRoundFloor_SW.png"/>
 </tile>
 <tile id="423">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampRoundTable_NE.png"/>
 </tile>
 <tile id="424">
  <image width="18" height="35" source="../graphics/kenney_furniturePack/Isometric/lampRoundTable_NW.png"/>
 </tile>
 <tile id="425">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampRoundTable_SE.png"/>
 </tile>
 <tile id="426">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampRoundTable_SW.png"/>
 </tile>
 <tile id="427">
  <image width="19" height="28" source="../graphics/kenney_furniturePack/Isometric/lampSquareCeiling_NE.png"/>
 </tile>
 <tile id="428">
  <image width="18" height="29" source="../graphics/kenney_furniturePack/Isometric/lampSquareCeiling_NW.png"/>
 </tile>
 <tile id="429">
  <image width="19" height="28" source="../graphics/kenney_furniturePack/Isometric/lampSquareCeiling_SE.png"/>
 </tile>
 <tile id="430">
  <image width="19" height="29" source="../graphics/kenney_furniturePack/Isometric/lampSquareCeiling_SW.png"/>
 </tile>
 <tile id="431">
  <image width="19" height="78" source="../graphics/kenney_furniturePack/Isometric/lampSquareFloor_NE.png"/>
 </tile>
 <tile id="432">
  <image width="18" height="78" source="../graphics/kenney_furniturePack/Isometric/lampSquareFloor_NW.png"/>
 </tile>
 <tile id="433">
  <image width="19" height="78" source="../graphics/kenney_furniturePack/Isometric/lampSquareFloor_SE.png"/>
 </tile>
 <tile id="434">
  <image width="19" height="78" source="../graphics/kenney_furniturePack/Isometric/lampSquareFloor_SW.png"/>
 </tile>
 <tile id="435">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampSquareTable_NE.png"/>
 </tile>
 <tile id="436">
  <image width="18" height="35" source="../graphics/kenney_furniturePack/Isometric/lampSquareTable_NW.png"/>
 </tile>
 <tile id="437">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampSquareTable_SE.png"/>
 </tile>
 <tile id="438">
  <image width="19" height="35" source="../graphics/kenney_furniturePack/Isometric/lampSquareTable_SW.png"/>
 </tile>
 <tile id="439">
  <image width="37" height="24" source="../graphics/kenney_furniturePack/Isometric/laptop_NE.png"/>
 </tile>
 <tile id="440">
  <image width="37" height="24" source="../graphics/kenney_furniturePack/Isometric/laptop_NW.png"/>
 </tile>
 <tile id="441">
  <image width="38" height="38" source="../graphics/kenney_furniturePack/Isometric/laptop_SE.png"/>
 </tile>
 <tile id="442">
  <image width="37" height="38" source="../graphics/kenney_furniturePack/Isometric/laptop_SW.png"/>
 </tile>
 <tile id="443">
  <image width="66" height="73" source="../graphics/kenney_furniturePack/Isometric/loungeChair_NE.png"/>
 </tile>
 <tile id="444">
  <image width="67" height="73" source="../graphics/kenney_furniturePack/Isometric/loungeChair_NW.png"/>
 </tile>
 <tile id="445">
  <image width="67" height="77" source="../graphics/kenney_furniturePack/Isometric/loungeChair_SE.png"/>
 </tile>
 <tile id="446">
  <image width="66" height="77" source="../graphics/kenney_furniturePack/Isometric/loungeChair_SW.png"/>
 </tile>
 <tile id="447">
  <image width="77" height="73" source="../graphics/kenney_furniturePack/Isometric/loungeChairRelax_NE.png"/>
 </tile>
 <tile id="448">
  <image width="77" height="73" source="../graphics/kenney_furniturePack/Isometric/loungeChairRelax_NW.png"/>
 </tile>
 <tile id="449">
  <image width="78" height="97" source="../graphics/kenney_furniturePack/Isometric/loungeChairRelax_SE.png"/>
 </tile>
 <tile id="450">
  <image width="77" height="96" source="../graphics/kenney_furniturePack/Isometric/loungeChairRelax_SW.png"/>
 </tile>
 <tile id="451">
  <image width="103" height="99" source="../graphics/kenney_furniturePack/Isometric/loungeSofa_NE.png"/>
 </tile>
 <tile id="452">
  <image width="104" height="99" source="../graphics/kenney_furniturePack/Isometric/loungeSofa_NW.png"/>
 </tile>
 <tile id="453">
  <image width="104" height="103" source="../graphics/kenney_furniturePack/Isometric/loungeSofa_SE.png"/>
 </tile>
 <tile id="454">
  <image width="103" height="103" source="../graphics/kenney_furniturePack/Isometric/loungeSofa_SW.png"/>
 </tile>
 <tile id="455">
  <image width="148" height="99" source="../graphics/kenney_furniturePack/Isometric/loungeSofaCorner_NE.png"/>
 </tile>
 <tile id="456">
  <image width="104" height="134" source="../graphics/kenney_furniturePack/Isometric/loungeSofaCorner_NW.png"/>
 </tile>
 <tile id="457">
  <image width="148" height="108" source="../graphics/kenney_furniturePack/Isometric/loungeSofaCorner_SE.png"/>
 </tile>
 <tile id="458">
  <image width="103" height="135" source="../graphics/kenney_furniturePack/Isometric/loungeSofaCorner_SW.png"/>
 </tile>
 <tile id="459">
  <image width="131" height="99" source="../graphics/kenney_furniturePack/Isometric/loungeSofaLong_NE.png"/>
 </tile>
 <tile id="460">
  <image width="104" height="110" source="../graphics/kenney_furniturePack/Isometric/loungeSofaLong_NW.png"/>
 </tile>
 <tile id="461">
  <image width="131" height="103" source="../graphics/kenney_furniturePack/Isometric/loungeSofaLong_SE.png"/>
 </tile>
 <tile id="462">
  <image width="103" height="121" source="../graphics/kenney_furniturePack/Isometric/loungeSofaLong_SW.png"/>
 </tile>
 <tile id="463">
  <image width="68" height="63" source="../graphics/kenney_furniturePack/Isometric/loungeSofaOttoman_NE.png"/>
 </tile>
 <tile id="464">
  <image width="68" height="63" source="../graphics/kenney_furniturePack/Isometric/loungeSofaOttoman_NW.png"/>
 </tile>
 <tile id="465">
  <image width="68" height="63" source="../graphics/kenney_furniturePack/Isometric/loungeSofaOttoman_SE.png"/>
 </tile>
 <tile id="466">
  <image width="67" height="63" source="../graphics/kenney_furniturePack/Isometric/loungeSofaOttoman_SW.png"/>
 </tile>
 <tile id="467">
  <image width="40" height="73" source="../graphics/kenney_furniturePack/Isometric/paneling_NE.png"/>
 </tile>
 <tile id="468">
  <image width="41" height="72" source="../graphics/kenney_furniturePack/Isometric/paneling_NW.png"/>
 </tile>
 <tile id="469">
  <image width="40" height="73" source="../graphics/kenney_furniturePack/Isometric/paneling_SE.png"/>
 </tile>
 <tile id="470">
  <image width="40" height="73" source="../graphics/kenney_furniturePack/Isometric/paneling_SW.png"/>
 </tile>
 <tile id="471">
  <image width="21" height="23" source="../graphics/kenney_furniturePack/Isometric/pillow_NE.png"/>
 </tile>
 <tile id="472">
  <image width="21" height="24" source="../graphics/kenney_furniturePack/Isometric/pillow_NW.png"/>
 </tile>
 <tile id="473">
  <image width="21" height="29" source="../graphics/kenney_furniturePack/Isometric/pillow_SE.png"/>
 </tile>
 <tile id="474">
  <image width="21" height="29" source="../graphics/kenney_furniturePack/Isometric/pillow_SW.png"/>
 </tile>
 <tile id="475">
  <image width="32" height="31" source="../graphics/kenney_furniturePack/Isometric/pillowLong_NE.png"/>
 </tile>
 <tile id="476">
  <image width="33" height="32" source="../graphics/kenney_furniturePack/Isometric/pillowLong_NW.png"/>
 </tile>
 <tile id="477">
  <image width="33" height="38" source="../graphics/kenney_furniturePack/Isometric/pillowLong_SE.png"/>
 </tile>
 <tile id="478">
  <image width="33" height="37" source="../graphics/kenney_furniturePack/Isometric/pillowLong_SW.png"/>
 </tile>
 <tile id="479">
  <image width="10" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall1_NE.png"/>
 </tile>
 <tile id="480">
  <image width="9" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall1_NW.png"/>
 </tile>
 <tile id="481">
  <image width="11" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall1_SE.png"/>
 </tile>
 <tile id="482">
  <image width="9" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall1_SW.png"/>
 </tile>
 <tile id="483">
  <image width="10" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall2_NE.png"/>
 </tile>
 <tile id="484">
  <image width="9" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall2_NW.png"/>
 </tile>
 <tile id="485">
  <image width="11" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall2_SE.png"/>
 </tile>
 <tile id="486">
  <image width="9" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall2_SW.png"/>
 </tile>
 <tile id="487">
  <image width="10" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall3_NE.png"/>
 </tile>
 <tile id="488">
  <image width="10" height="14" source="../graphics/kenney_furniturePack/Isometric/plantSmall3_NW.png"/>
 </tile>
 <tile id="489">
  <image width="10" height="15" source="../graphics/kenney_furniturePack/Isometric/plantSmall3_SE.png"/>
 </tile>
 <tile id="490">
  <image width="10" height="15" source="../graphics/kenney_furniturePack/Isometric/plantSmall3_SW.png"/>
 </tile>
 <tile id="491">
  <image width="21" height="61" source="../graphics/kenney_furniturePack/Isometric/pottedPlant_NE.png"/>
 </tile>
 <tile id="492">
  <image width="21" height="61" source="../graphics/kenney_furniturePack/Isometric/pottedPlant_NW.png"/>
 </tile>
 <tile id="493">
  <image width="21" height="60" source="../graphics/kenney_furniturePack/Isometric/pottedPlant_SE.png"/>
 </tile>
 <tile id="494">
  <image width="21" height="60" source="../graphics/kenney_furniturePack/Isometric/pottedPlant_SW.png"/>
 </tile>
 <tile id="495">
  <image width="30" height="36" source="../graphics/kenney_furniturePack/Isometric/radio_NE.png"/>
 </tile>
 <tile id="496">
  <image width="31" height="36" source="../graphics/kenney_furniturePack/Isometric/radio_NW.png"/>
 </tile>
 <tile id="497">
  <image width="31" height="36" source="../graphics/kenney_furniturePack/Isometric/radio_SE.png"/>
 </tile>
 <tile id="498">
  <image width="30" height="36" source="../graphics/kenney_furniturePack/Isometric/radio_SW.png"/>
 </tile>
 <tile id="499">
  <image width="188" height="134" source="../graphics/kenney_furniturePack/Isometric/rugRectangle_NE.png"/>
 </tile>
 <tile id="500">
  <image width="188" height="133" source="../graphics/kenney_furniturePack/Isometric/rugRectangle_NW.png"/>
 </tile>
 <tile id="501">
  <image width="188" height="134" source="../graphics/kenney_furniturePack/Isometric/rugRectangle_SE.png"/>
 </tile>
 <tile id="502">
  <image width="188" height="134" source="../graphics/kenney_furniturePack/Isometric/rugRectangle_SW.png"/>
 </tile>
 <tile id="503">
  <image width="99" height="70" source="../graphics/kenney_furniturePack/Isometric/rugRound_NE.png"/>
 </tile>
 <tile id="504">
  <image width="98" height="70" source="../graphics/kenney_furniturePack/Isometric/rugRound_NW.png"/>
 </tile>
 <tile id="505">
  <image width="99" height="71" source="../graphics/kenney_furniturePack/Isometric/rugRound_SE.png"/>
 </tile>
 <tile id="506">
  <image width="99" height="70" source="../graphics/kenney_furniturePack/Isometric/rugRound_SW.png"/>
 </tile>
 <tile id="507">
  <image width="148" height="105" source="../graphics/kenney_furniturePack/Isometric/rugRounded_NE.png"/>
 </tile>
 <tile id="508">
  <image width="147" height="105" source="../graphics/kenney_furniturePack/Isometric/rugRounded_NW.png"/>
 </tile>
 <tile id="509">
  <image width="148" height="105" source="../graphics/kenney_furniturePack/Isometric/rugRounded_SE.png"/>
 </tile>
 <tile id="510">
  <image width="148" height="105" source="../graphics/kenney_furniturePack/Isometric/rugRounded_SW.png"/>
 </tile>
 <tile id="511">
  <image width="138" height="98" source="../graphics/kenney_furniturePack/Isometric/rugSquare_NE.png"/>
 </tile>
 <tile id="512">
  <image width="138" height="98" source="../graphics/kenney_furniturePack/Isometric/rugSquare_NW.png"/>
 </tile>
 <tile id="513">
  <image width="138" height="98" source="../graphics/kenney_furniturePack/Isometric/rugSquare_SE.png"/>
 </tile>
 <tile id="514">
  <image width="138" height="98" source="../graphics/kenney_furniturePack/Isometric/rugSquare_SW.png"/>
 </tile>
 <tile id="515">
  <image width="85" height="142" source="../graphics/kenney_furniturePack/Isometric/shower_NE.png"/>
 </tile>
 <tile id="516">
  <image width="85" height="143" source="../graphics/kenney_furniturePack/Isometric/shower_NW.png"/>
 </tile>
 <tile id="517">
  <image width="85" height="142" source="../graphics/kenney_furniturePack/Isometric/shower_SE.png"/>
 </tile>
 <tile id="518">
  <image width="85" height="143" source="../graphics/kenney_furniturePack/Isometric/shower_SW.png"/>
 </tile>
 <tile id="519">
  <image width="57" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTable_NE.png"/>
 </tile>
 <tile id="520">
  <image width="57" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTable_NW.png"/>
 </tile>
 <tile id="521">
  <image width="58" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTable_SE.png"/>
 </tile>
 <tile id="522">
  <image width="57" height="69" source="../graphics/kenney_furniturePack/Isometric/sideTable_SW.png"/>
 </tile>
 <tile id="523">
  <image width="57" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTableDrawers_NE.png"/>
 </tile>
 <tile id="524">
  <image width="57" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTableDrawers_NW.png"/>
 </tile>
 <tile id="525">
  <image width="58" height="68" source="../graphics/kenney_furniturePack/Isometric/sideTableDrawers_SE.png"/>
 </tile>
 <tile id="526">
  <image width="57" height="69" source="../graphics/kenney_furniturePack/Isometric/sideTableDrawers_SW.png"/>
 </tile>
 <tile id="527">
  <image width="23" height="63" source="../graphics/kenney_furniturePack/Isometric/speaker_NE.png"/>
 </tile>
 <tile id="528">
  <image width="22" height="63" source="../graphics/kenney_furniturePack/Isometric/speaker_NW.png"/>
 </tile>
 <tile id="529">
  <image width="23" height="64" source="../graphics/kenney_furniturePack/Isometric/speaker_SE.png"/>
 </tile>
 <tile id="530">
  <image width="23" height="64" source="../graphics/kenney_furniturePack/Isometric/speaker_SW.png"/>
 </tile>
 <tile id="531">
  <image width="22" height="38" source="../graphics/kenney_furniturePack/Isometric/speakerSmall_NE.png"/>
 </tile>
 <tile id="532">
  <image width="21" height="37" source="../graphics/kenney_furniturePack/Isometric/speakerSmall_NW.png"/>
 </tile>
 <tile id="533">
  <image width="22" height="37" source="../graphics/kenney_furniturePack/Isometric/speakerSmall_SE.png"/>
 </tile>
 <tile id="534">
  <image width="22" height="38" source="../graphics/kenney_furniturePack/Isometric/speakerSmall_SW.png"/>
 </tile>
 <tile id="535">
  <image width="28" height="48" source="../graphics/kenney_furniturePack/Isometric/stoolBar_NE.png"/>
 </tile>
 <tile id="536">
  <image width="27" height="48" source="../graphics/kenney_furniturePack/Isometric/stoolBar_NW.png"/>
 </tile>
 <tile id="537">
  <image width="27" height="49" source="../graphics/kenney_furniturePack/Isometric/stoolBar_SE.png"/>
 </tile>
 <tile id="538">
  <image width="28" height="49" source="../graphics/kenney_furniturePack/Isometric/stoolBar_SW.png"/>
 </tile>
 <tile id="539">
  <image width="23" height="45" source="../graphics/kenney_furniturePack/Isometric/stoolBarSquare_NE.png"/>
 </tile>
 <tile id="540">
  <image width="23" height="46" source="../graphics/kenney_furniturePack/Isometric/stoolBarSquare_NW.png"/>
 </tile>
 <tile id="541">
  <image width="23" height="46" source="../graphics/kenney_furniturePack/Isometric/stoolBarSquare_SE.png"/>
 </tile>
 <tile id="542">
  <image width="24" height="46" source="../graphics/kenney_furniturePack/Isometric/stoolBarSquare_SW.png"/>
 </tile>
 <tile id="543">
  <image width="97" height="94" source="../graphics/kenney_furniturePack/Isometric/table_NE.png"/>
 </tile>
 <tile id="544">
  <image width="97" height="93" source="../graphics/kenney_furniturePack/Isometric/table_NW.png"/>
 </tile>
 <tile id="545">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/table_SE.png"/>
 </tile>
 <tile id="546">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/table_SW.png"/>
 </tile>
 <tile id="547">
  <image width="97" height="94" source="../graphics/kenney_furniturePack/Isometric/tableCloth_NE.png"/>
 </tile>
 <tile id="548">
  <image width="97" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCloth_NW.png"/>
 </tile>
 <tile id="549">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCloth_SE.png"/>
 </tile>
 <tile id="550">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCloth_SW.png"/>
 </tile>
 <tile id="551">
  <image width="81" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffee_NE.png"/>
 </tile>
 <tile id="552">
  <image width="81" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffee_NW.png"/>
 </tile>
 <tile id="553">
  <image width="80" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffee_SE.png"/>
 </tile>
 <tile id="554">
  <image width="80" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffee_SW.png"/>
 </tile>
 <tile id="555">
  <image width="81" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlass_NE.png"/>
 </tile>
 <tile id="556">
  <image width="81" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlass_NW.png"/>
 </tile>
 <tile id="557">
  <image width="80" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlass_SE.png"/>
 </tile>
 <tile id="558">
  <image width="80" height="74" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlass_SW.png"/>
 </tile>
 <tile id="559">
  <image width="61" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlassSquare_NE.png"/>
 </tile>
 <tile id="560">
  <image width="61" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlassSquare_NW.png"/>
 </tile>
 <tile id="561">
  <image width="60" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlassSquare_SE.png"/>
 </tile>
 <tile id="562">
  <image width="60" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeGlassSquare_SW.png"/>
 </tile>
 <tile id="563">
  <image width="61" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeSquare_NE.png"/>
 </tile>
 <tile id="564">
  <image width="61" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeSquare_NW.png"/>
 </tile>
 <tile id="565">
  <image width="60" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeSquare_SE.png"/>
 </tile>
 <tile id="566">
  <image width="60" height="60" source="../graphics/kenney_furniturePack/Isometric/tableCoffeeSquare_SW.png"/>
 </tile>
 <tile id="567">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCross_NE.png"/>
 </tile>
 <tile id="568">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCross_NW.png"/>
 </tile>
 <tile id="569">
  <image width="99" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCross_SE.png"/>
 </tile>
 <tile id="570">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCross_SW.png"/>
 </tile>
 <tile id="571">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCrossCloth_NE.png"/>
 </tile>
 <tile id="572">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCrossCloth_NW.png"/>
 </tile>
 <tile id="573">
  <image width="99" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCrossCloth_SE.png"/>
 </tile>
 <tile id="574">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableCrossCloth_SW.png"/>
 </tile>
 <tile id="575">
  <image width="97" height="94" source="../graphics/kenney_furniturePack/Isometric/tableGlass_NE.png"/>
 </tile>
 <tile id="576">
  <image width="97" height="93" source="../graphics/kenney_furniturePack/Isometric/tableGlass_NW.png"/>
 </tile>
 <tile id="577">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableGlass_SE.png"/>
 </tile>
 <tile id="578">
  <image width="98" height="93" source="../graphics/kenney_furniturePack/Isometric/tableGlass_SW.png"/>
 </tile>
 <tile id="579">
  <image width="83" height="69" source="../graphics/kenney_furniturePack/Isometric/tableRound_NE.png"/>
 </tile>
 <tile id="580">
  <image width="82" height="69" source="../graphics/kenney_furniturePack/Isometric/tableRound_NW.png"/>
 </tile>
 <tile id="581">
  <image width="83" height="69" source="../graphics/kenney_furniturePack/Isometric/tableRound_SE.png"/>
 </tile>
 <tile id="582">
  <image width="83" height="68" source="../graphics/kenney_furniturePack/Isometric/tableRound_SW.png"/>
 </tile>
 <tile id="583">
  <image width="22" height="18" source="../graphics/kenney_furniturePack/Isometric/televisionAntenna_NE.png"/>
 </tile>
 <tile id="584">
  <image width="22" height="17" source="../graphics/kenney_furniturePack/Isometric/televisionAntenna_NW.png"/>
 </tile>
 <tile id="585">
  <image width="22" height="18" source="../graphics/kenney_furniturePack/Isometric/televisionAntenna_SE.png"/>
 </tile>
 <tile id="586">
  <image width="22" height="18" source="../graphics/kenney_furniturePack/Isometric/televisionAntenna_SW.png"/>
 </tile>
 <tile id="587">
  <image width="55" height="67" source="../graphics/kenney_furniturePack/Isometric/televisionModern_NE.png"/>
 </tile>
 <tile id="588">
  <image width="54" height="67" source="../graphics/kenney_furniturePack/Isometric/televisionModern_NW.png"/>
 </tile>
 <tile id="589">
  <image width="54" height="68" source="../graphics/kenney_furniturePack/Isometric/televisionModern_SE.png"/>
 </tile>
 <tile id="590">
  <image width="55" height="68" source="../graphics/kenney_furniturePack/Isometric/televisionModern_SW.png"/>
 </tile>
 <tile id="591">
  <image width="47" height="53" source="../graphics/kenney_furniturePack/Isometric/televisionVintage_NE.png"/>
 </tile>
 <tile id="592">
  <image width="46" height="53" source="../graphics/kenney_furniturePack/Isometric/televisionVintage_NW.png"/>
 </tile>
 <tile id="593">
  <image width="46" height="53" source="../graphics/kenney_furniturePack/Isometric/televisionVintage_SE.png"/>
 </tile>
 <tile id="594">
  <image width="46" height="53" source="../graphics/kenney_furniturePack/Isometric/televisionVintage_SW.png"/>
 </tile>
 <tile id="595">
  <image width="54" height="44" source="../graphics/kenney_furniturePack/Isometric/toilet_NE.png"/>
 </tile>
 <tile id="596">
  <image width="54" height="45" source="../graphics/kenney_furniturePack/Isometric/toilet_NW.png"/>
 </tile>
 <tile id="597">
  <image width="54" height="70" source="../graphics/kenney_furniturePack/Isometric/toilet_SE.png"/>
 </tile>
 <tile id="598">
  <image width="54" height="71" source="../graphics/kenney_furniturePack/Isometric/toilet_SW.png"/>
 </tile>
 <tile id="599">
  <image width="25" height="45" source="../graphics/kenney_furniturePack/Isometric/trashcan_NE.png"/>
 </tile>
 <tile id="600">
  <image width="25" height="45" source="../graphics/kenney_furniturePack/Isometric/trashcan_NW.png"/>
 </tile>
 <tile id="601">
  <image width="25" height="46" source="../graphics/kenney_furniturePack/Isometric/trashcan_SE.png"/>
 </tile>
 <tile id="602">
  <image width="25" height="46" source="../graphics/kenney_furniturePack/Isometric/trashcan_SW.png"/>
 </tile>
 <tile id="603">
  <image width="79" height="153" source="../graphics/kenney_furniturePack/Isometric/wall_NE.png"/>
 </tile>
 <tile id="604">
  <image width="79" height="154" source="../graphics/kenney_furniturePack/Isometric/wall_NW.png"/>
 </tile>
 <tile id="605">
  <image width="80" height="153" source="../graphics/kenney_furniturePack/Isometric/wall_SE.png"/>
 </tile>
 <tile id="606">
  <image width="80" height="154" source="../graphics/kenney_furniturePack/Isometric/wall_SW.png"/>
 </tile>
 <tile id="607">
  <image width="38" height="156" source="../graphics/kenney_furniturePack/Isometric/wallCorner_NE.png"/>
 </tile>
 <tile id="608">
  <image width="83" height="124" source="../graphics/kenney_furniturePack/Isometric/wallCorner_NW.png"/>
 </tile>
 <tile id="609">
  <image width="38" height="156" source="../graphics/kenney_furniturePack/Isometric/wallCorner_SE.png"/>
 </tile>
 <tile id="610">
  <image width="83" height="124" source="../graphics/kenney_furniturePack/Isometric/wallCorner_SW.png"/>
 </tile>
 <tile id="611">
  <image width="41" height="156" source="../graphics/kenney_furniturePack/Isometric/wallCornerRond_NE.png"/>
 </tile>
 <tile id="612">
  <image width="83" height="127" source="../graphics/kenney_furniturePack/Isometric/wallCornerRond_NW.png"/>
 </tile>
 <tile id="613">
  <image width="42" height="156" source="../graphics/kenney_furniturePack/Isometric/wallCornerRond_SE.png"/>
 </tile>
 <tile id="614">
  <image width="83" height="127" source="../graphics/kenney_furniturePack/Isometric/wallCornerRond_SW.png"/>
 </tile>
 <tile id="615">
  <image width="79" height="153" source="../graphics/kenney_furniturePack/Isometric/wallDoorway_NE.png"/>
 </tile>
 <tile id="616">
  <image width="79" height="154" source="../graphics/kenney_furniturePack/Isometric/wallDoorway_NW.png"/>
 </tile>
 <tile id="617">
  <image width="80" height="153" source="../graphics/kenney_furniturePack/Isometric/wallDoorway_SE.png"/>
 </tile>
 <tile id="618">
  <image width="80" height="154" source="../graphics/kenney_furniturePack/Isometric/wallDoorway_SW.png"/>
 </tile>
 <tile id="619">
  <image width="79" height="153" source="../graphics/kenney_furniturePack/Isometric/wallDoorwayWide_NE.png"/>
 </tile>
 <tile id="620">
  <image width="79" height="154" source="../graphics/kenney_furniturePack/Isometric/wallDoorwayWide_NW.png"/>
 </tile>
 <tile id="621">
  <image width="80" height="153" source="../graphics/kenney_furniturePack/Isometric/wallDoorwayWide_SE.png"/>
 </tile>
 <tile id="622">
  <image width="80" height="154" source="../graphics/kenney_furniturePack/Isometric/wallDoorwayWide_SW.png"/>
 </tile>
 <tile id="623">
  <image width="42" height="127" source="../graphics/kenney_furniturePack/Isometric/wallHalf_NE.png"/>
 </tile>
 <tile id="624">
  <image width="41" height="127" source="../graphics/kenney_furniturePack/Isometric/wallHalf_NW.png"/>
 </tile>
 <tile id="625">
  <image width="42" height="127" source="../graphics/kenney_furniturePack/Isometric/wallHalf_SE.png"/>
 </tile>
 <tile id="626">
  <image width="42" height="127" source="../graphics/kenney_furniturePack/Isometric/wallHalf_SW.png"/>
 </tile>
 <tile id="627">
  <image width="79" height="153" source="../graphics/kenney_furniturePack/Isometric/wallWindow_NE.png"/>
 </tile>
 <tile id="628">
  <image width="79" height="154" source="../graphics/kenney_furniturePack/Isometric/wallWindow_NW.png"/>
 </tile>
 <tile id="629">
  <image width="80" height="153" source="../graphics/kenney_furniturePack/Isometric/wallWindow_SE.png"/>
 </tile>
 <tile id="630">
  <image width="80" height="154" source="../graphics/kenney_furniturePack/Isometric/wallWindow_SW.png"/>
 </tile>
 <tile id="631">
  <image width="79" height="153" source="../graphics/kenney_furniturePack/Isometric/wallWindowSlide_NE.png"/>
 </tile>
 <tile id="632">
  <image width="32" height="47" source="../graphics/isometricFurniture/isometriccabinet3.png"/>
 </tile>
 <tile id="633">
  <image width="32" height="63" source="../graphics/isometricFurniture/isometricchair0.png"/>
 </tile>
 <tile id="634">
  <image width="32" height="56" source="../graphics/isometricFurniture/isometricchair1.png"/>
 </tile>
 <tile id="635">
  <image width="32" height="63" source="../graphics/isometricFurniture/isometricchair2.png"/>
 </tile>
 <tile id="636">
  <image width="32" height="55" source="../graphics/isometricFurniture/isometricchair3.png"/>
 </tile>
 <tile id="637">
  <image width="64" height="58" source="../graphics/isometricFurniture/isometrictable0.png"/>
 </tile>
 <tile id="638">
  <image width="64" height="45" source="../graphics/isometricFurniture/isometricbed0.png"/>
 </tile>
 <tile id="639">
  <image width="64" height="44" source="../graphics/isometricFurniture/isometricbed1.png"/>
 </tile>
 <tile id="640">
  <image width="64" height="45" source="../graphics/isometricFurniture/isometricbed2.png"/>
 </tile>
 <tile id="641">
  <image width="64" height="45" source="../graphics/isometricFurniture/isometricbed3.png"/>
 </tile>
 <tile id="642">
  <image width="32" height="47" source="../graphics/isometricFurniture/isometriccabinet.png"/>
 </tile>
 <tile id="643">
  <image width="32" height="47" source="../graphics/isometricFurniture/isometriccabinet1.png"/>
 </tile>
 <tile id="644">
  <image width="32" height="47" source="../graphics/isometricFurniture/isometriccabinet2.png"/>
 </tile>
 <tile id="645">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksBrown_b.png"/>
 </tile>
 <tile id="646">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksRed_a.png"/>
 </tile>
 <tile id="647">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksRed_b.png"/>
 </tile>
 <tile id="648">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksRedDamaged_a.png"/>
 </tile>
 <tile id="649">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksRedDamaged_b.png"/>
 </tile>
 <tile id="650">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrown_a.png"/>
 </tile>
 <tile id="651">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrown_b.png"/>
 </tile>
 <tile id="652">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrownBooksDamaged_a.png"/>
 </tile>
 <tile id="653">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrownBooksDamaged_b.png"/>
 </tile>
 <tile id="654">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrownDamaged_a.png"/>
 </tile>
 <tile id="655">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBrownDamaged_b.png"/>
 </tile>
 <tile id="656">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfRed_a.png"/>
 </tile>
 <tile id="657">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfRed_b.png"/>
 </tile>
 <tile id="658">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfRedDamaged_a.png"/>
 </tile>
 <tile id="659">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfRedDamaged_b.png"/>
 </tile>
 <tile id="660">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairBrown_a.png"/>
 </tile>
 <tile id="661">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairBrown_b.png"/>
 </tile>
 <tile id="662">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairBrown_c.png"/>
 </tile>
 <tile id="663">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairBrown_d.png"/>
 </tile>
 <tile id="664">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairBrownDamaged_a.png"/>
 </tile>
 <tile id="665">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairBrownDamaged_b.png"/>
 </tile>
 <tile id="666">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairBrownDamaged_c.png"/>
 </tile>
 <tile id="667">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairBrownDamaged_d.png"/>
 </tile>
 <tile id="668">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairGreen_a.png"/>
 </tile>
 <tile id="669">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairGreen_b.png"/>
 </tile>
 <tile id="670">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairGreen_c.png"/>
 </tile>
 <tile id="671">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairGreen_d.png"/>
 </tile>
 <tile id="672">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairGreenDamaged_a.png"/>
 </tile>
 <tile id="673">
  <image width="55" height="79" source="../graphics/IIP - Outlined/furniture/chairGreenDamaged_b.png"/>
 </tile>
 <tile id="674">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairGreenDamaged_c.png"/>
 </tile>
 <tile id="675">
  <image width="55" height="71" source="../graphics/IIP - Outlined/furniture/chairGreenDamaged_d.png"/>
 </tile>
 <tile id="676">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableBrown.png"/>
 </tile>
 <tile id="677">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableBrownDamaged.png"/>
 </tile>
 <tile id="678">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableGray.png"/>
 </tile>
 <tile id="679">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableGrayDamaged.png"/>
 </tile>
 <tile id="680">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableGreen.png"/>
 </tile>
 <tile id="681">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableGreenDamaged.png"/>
 </tile>
 <tile id="682">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableRed.png"/>
 </tile>
 <tile id="683">
  <image width="87" height="71" source="../graphics/IIP - Outlined/furniture/coffeeTableRedDamaged.png"/>
 </tile>
 <tile id="684">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskBrown_a.png"/>
 </tile>
 <tile id="685">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskBrown_b.png"/>
 </tile>
 <tile id="686">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskBrownDamaged_a.png"/>
 </tile>
 <tile id="687">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskBrownDamaged_b.png"/>
 </tile>
 <tile id="688">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskGray_a.png"/>
 </tile>
 <tile id="689">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskGray_b.png"/>
 </tile>
 <tile id="690">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskGrayDamaged_a.png"/>
 </tile>
 <tile id="691">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskGrayDamaged_b.png"/>
 </tile>
 <tile id="692">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskRed_a.png"/>
 </tile>
 <tile id="693">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskRed_b.png"/>
 </tile>
 <tile id="694">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskRedDamaged_a.png"/>
 </tile>
 <tile id="695">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskRedDamaged_b.png"/>
 </tile>
 <tile id="696">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskWhite_a.png"/>
 </tile>
 <tile id="697">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskWhite_b.png"/>
 </tile>
 <tile id="698">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskWhiteDamaged_a.png"/>
 </tile>
 <tile id="699">
  <image width="103" height="95" source="../graphics/IIP - Outlined/furniture/deskWhiteDamaged_b.png"/>
 </tile>
 <tile id="700">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigBrown_a.png"/>
 </tile>
 <tile id="701">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigBrown_b.png"/>
 </tile>
 <tile id="702">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigBrown_c.png"/>
 </tile>
 <tile id="703">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigBrown_d.png"/>
 </tile>
 <tile id="704">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigBrownDamaged_a.png"/>
 </tile>
 <tile id="705">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigBrownDamaged_b.png"/>
 </tile>
 <tile id="706">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigBrownDamaged_c.png"/>
 </tile>
 <tile id="707">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigDamaged_d.png"/>
 </tile>
 <tile id="708">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGray_a.png"/>
 </tile>
 <tile id="709">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGray_b.png"/>
 </tile>
 <tile id="710">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGray_c.png"/>
 </tile>
 <tile id="711">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGray_d.png"/>
 </tile>
 <tile id="712">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGrayDamaged_a.png"/>
 </tile>
 <tile id="713">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGrayDamaged_b.png"/>
 </tile>
 <tile id="714">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGrayDamaged_c.png"/>
 </tile>
 <tile id="715">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGrayDamaged_d.png"/>
 </tile>
 <tile id="716">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGreen_a.png"/>
 </tile>
 <tile id="717">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGreen_b.png"/>
 </tile>
 <tile id="718">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGreen_c.png"/>
 </tile>
 <tile id="719">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGreen_d.png"/>
 </tile>
 <tile id="720">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGreenDamaged_a.png"/>
 </tile>
 <tile id="721">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigGreenDamaged_b.png"/>
 </tile>
 <tile id="722">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGreenDamaged_c.png"/>
 </tile>
 <tile id="723">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigGreenDamaged_d.png"/>
 </tile>
 <tile id="724">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigRed_a.png"/>
 </tile>
 <tile id="725">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigRed_b.png"/>
 </tile>
 <tile id="726">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigRed_c.png"/>
 </tile>
 <tile id="727">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigRed_d.png"/>
 </tile>
 <tile id="728">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigRedDamaged_a.png"/>
 </tile>
 <tile id="729">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/sofaBigRedDamaged_b.png"/>
 </tile>
 <tile id="730">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigRedDamaged_c.png"/>
 </tile>
 <tile id="731">
  <image width="95" height="83" source="../graphics/IIP - Outlined/furniture/sofaBigRedDamaged_d.png"/>
 </tile>
 <tile id="732">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGray_a.png"/>
 </tile>
 <tile id="733">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGray_b.png"/>
 </tile>
 <tile id="734">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGray_c.png"/>
 </tile>
 <tile id="735">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGray_d.png"/>
 </tile>
 <tile id="736">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGrayDamaged_a.png"/>
 </tile>
 <tile id="737">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGrayDamaged_b.png"/>
 </tile>
 <tile id="738">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGrayDamaged_c.png"/>
 </tile>
 <tile id="739">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGrayDamaged_d.png"/>
 </tile>
 <tile id="740">
  <image width="53" height="78" source="../graphics/IIP - Outlined/furniture/sofaGrayFlipped_a.png"/>
 </tile>
 <tile id="741">
  <image width="72" height="74" source="../graphics/IIP - Outlined/furniture/sofaGrayFlipped_b.png"/>
 </tile>
 <tile id="742">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGreen_a.png"/>
 </tile>
 <tile id="743">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGreen_b.png"/>
 </tile>
 <tile id="744">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGreen_c.png"/>
 </tile>
 <tile id="745">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGreen_d.png"/>
 </tile>
 <tile id="746">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGreenDamaged_a.png"/>
 </tile>
 <tile id="747">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaGreenDamaged_b.png"/>
 </tile>
 <tile id="748">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGreenDamaged_c.png"/>
 </tile>
 <tile id="749">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaGreenDamaged_d.png"/>
 </tile>
 <tile id="750">
  <image width="52" height="77" source="../graphics/IIP - Outlined/furniture/sofaGreenFlipped_a.png"/>
 </tile>
 <tile id="751">
  <image width="72" height="74" source="../graphics/IIP - Outlined/furniture/sofaGreenFlipped_b.png"/>
 </tile>
 <tile id="752">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaRed_a.png"/>
 </tile>
 <tile id="753">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaRed_b.png"/>
 </tile>
 <tile id="754">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaRed_c.png"/>
 </tile>
 <tile id="755">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaRed_d.png"/>
 </tile>
 <tile id="756">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaRedDamaged_a.png"/>
 </tile>
 <tile id="757">
  <image width="63" height="75" source="../graphics/IIP - Outlined/furniture/sofaRedDamaged_b.png"/>
 </tile>
 <tile id="758">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaRedDamaged_c.png"/>
 </tile>
 <tile id="759">
  <image width="63" height="67" source="../graphics/IIP - Outlined/furniture/sofaRedDamaged_d.png"/>
 </tile>
 <tile id="760">
  <image width="52" height="77" source="../graphics/IIP - Outlined/furniture/sofaRedFlipped_a.png"/>
 </tile>
 <tile id="761">
  <image width="72" height="73" source="../graphics/IIP - Outlined/furniture/sofaRedFlipped_b.png"/>
 </tile>
 <tile id="762">
  <image width="97" height="93" source="../graphics/IIP - Outlined/furniture/tableBlueRound.png"/>
 </tile>
 <tile id="763">
  <image width="97" height="93" source="../graphics/IIP - Outlined/furniture/tableBlueRoundDamaged.png"/>
 </tile>
 <tile id="764">
  <image width="97" height="94" source="../graphics/IIP - Outlined/furniture/tableGrayRound.png"/>
 </tile>
 <tile id="765">
  <image width="97" height="94" source="../graphics/IIP - Outlined/furniture/tableGrayRoundDamaged.png"/>
 </tile>
 <tile id="766">
  <image width="98" height="94" source="../graphics/IIP - Outlined/furniture/tableGreenRound.png"/>
 </tile>
 <tile id="767">
  <image width="98" height="94" source="../graphics/IIP - Outlined/furniture/tableGreenRoundDamaged.png"/>
 </tile>
 <tile id="768">
  <image width="135" height="111" source="../graphics/IIP - Outlined/furniture/tableSquareBrown.png"/>
 </tile>
 <tile id="769">
  <image width="135" height="111" source="../graphics/IIP - Outlined/furniture/tableSquareBrownDamaged.png"/>
 </tile>
 <tile id="770">
  <image width="135" height="111" source="../graphics/IIP - Outlined/furniture/tableSquareGreen.png"/>
 </tile>
 <tile id="771">
  <image width="135" height="111" source="../graphics/IIP - Outlined/furniture/tableSquareGreenDamaged.png"/>
 </tile>
 <tile id="772">
  <image width="98" height="94" source="../graphics/IIP - Outlined/furniture/tableWhiteRound.png"/>
 </tile>
 <tile id="773">
  <image width="97" height="94" source="../graphics/IIP - Outlined/furniture/tableWhiteRoundDamaged.png"/>
 </tile>
 <tile id="774">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandBrown_a.png"/>
 </tile>
 <tile id="775">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandBrown_b.png"/>
 </tile>
 <tile id="776">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandBrownDamaged_a.png"/>
 </tile>
 <tile id="777">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandBrownDamaged_b.png"/>
 </tile>
 <tile id="778">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandDark_a.png"/>
 </tile>
 <tile id="779">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandDark_b.png"/>
 </tile>
 <tile id="780">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandDarkDamaged_a.png"/>
 </tile>
 <tile id="781">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandDarkDamaged_b.png"/>
 </tile>
 <tile id="782">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandGreen_a.png"/>
 </tile>
 <tile id="783">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandGreen_b.png"/>
 </tile>
 <tile id="784">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandGreenDamaged_a.png"/>
 </tile>
 <tile id="785">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandGreenDamaged_b.png"/>
 </tile>
 <tile id="786">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandOlive_a.png"/>
 </tile>
 <tile id="787">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandOlive_b.png"/>
 </tile>
 <tile id="788">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandOliveDamaged_a.png"/>
 </tile>
 <tile id="789">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandOliveDamaged_b.png"/>
 </tile>
 <tile id="790">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandTan_a.png"/>
 </tile>
 <tile id="791">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandTan_b.png"/>
 </tile>
 <tile id="792">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandTanDamaged_a.png"/>
 </tile>
 <tile id="793">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/tvStandTanDamaged_b.png"/>
 </tile>
 <tile id="794">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityGray_a.png"/>
 </tile>
 <tile id="795">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityGray_b.png"/>
 </tile>
 <tile id="796">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityGrayDamaged_a.png"/>
 </tile>
 <tile id="797">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityGrayDamaged_b.png"/>
 </tile>
 <tile id="798">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityTan_a.png"/>
 </tile>
 <tile id="799">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityTan_b.png"/>
 </tile>
 <tile id="800">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityTanDamaged_a.png"/>
 </tile>
 <tile id="801">
  <image width="95" height="91" source="../graphics/IIP - Outlined/furniture/vanityTanDamaged_b.png"/>
 </tile>
 <tile id="802">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedBrown_a.png"/>
 </tile>
 <tile id="803">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedBrown_b.png"/>
 </tile>
 <tile id="804">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedBrownDamaged_a.png"/>
 </tile>
 <tile id="805">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedBrownDamaged_b.png"/>
 </tile>
 <tile id="806">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedGreen_a.png"/>
 </tile>
 <tile id="807">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedGreen_b.png"/>
 </tile>
 <tile id="808">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedGreenDamaged_a.png"/>
 </tile>
 <tile id="809">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedGreenDamaged_b.png"/>
 </tile>
 <tile id="810">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedPink_a.png"/>
 </tile>
 <tile id="811">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedPink_b.png"/>
 </tile>
 <tile id="812">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedPinkDamaged_a.png"/>
 </tile>
 <tile id="813">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedPinkDamaged_b.png"/>
 </tile>
 <tile id="814">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedWhite_a.png"/>
 </tile>
 <tile id="815">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedWhite_b.png"/>
 </tile>
 <tile id="816">
  <image width="151" height="110" source="../graphics/IIP - Outlined/furniture/bedWhiteDamaged_a.png"/>
 </tile>
 <tile id="817">
  <image width="151" height="109" source="../graphics/IIP - Outlined/furniture/bedWhiteDamaged_b.png"/>
 </tile>
 <tile id="818">
  <image width="103" height="183" source="../graphics/IIP - Outlined/furniture/bookshelfBooksBrown_a.png"/>
 </tile>
 <tile id="819">
  <image width="199" height="143" source="../graphics/IIP - Outlined/Props/bathtubDamaged_b.png"/>
 </tile>
 <tile id="820">
  <image width="52" height="95" source="../graphics/IIP - Outlined/Props/cactus.png"/>
 </tile>
 <tile id="821">
  <image width="37" height="52" source="../graphics/IIP - Outlined/Props/coffeMaker_a.png"/>
 </tile>
 <tile id="822">
  <image width="37" height="52" source="../graphics/IIP - Outlined/Props/coffeMaker_b.png"/>
 </tile>
 <tile id="823">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainBlue_a.png"/>
 </tile>
 <tile id="824">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainBlue_b.png"/>
 </tile>
 <tile id="825">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainPeach_a.png"/>
 </tile>
 <tile id="826">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainPeach_b.png"/>
 </tile>
 <tile id="827">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainYellow_a.png"/>
 </tile>
 <tile id="828">
  <image width="87" height="132" source="../graphics/IIP - Outlined/Props/courtainYellow_b.png"/>
 </tile>
 <tile id="829">
  <image width="39" height="47" source="../graphics/IIP - Outlined/Props/cubeBlack.png"/>
 </tile>
 <tile id="830">
  <image width="39" height="47" source="../graphics/IIP - Outlined/Props/cubeBlue.png"/>
 </tile>
 <tile id="831">
  <image width="39" height="47" source="../graphics/IIP - Outlined/Props/cubeBrown.png"/>
 </tile>
 <tile id="832">
  <image width="39" height="47" source="../graphics/IIP - Outlined/Props/cubeWhite.png"/>
 </tile>
 <tile id="833">
  <image width="57" height="77" source="../graphics/IIP - Outlined/Props/flowers.png"/>
 </tile>
 <tile id="834">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeBlue_a.png"/>
 </tile>
 <tile id="835">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeBlue_b.png"/>
 </tile>
 <tile id="836">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeGreen_a.png"/>
 </tile>
 <tile id="837">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeGreen_b.png"/>
 </tile>
 <tile id="838">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeOrange_a.png"/>
 </tile>
 <tile id="839">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargeOrange_b.png"/>
 </tile>
 <tile id="840">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargePink_a.png"/>
 </tile>
 <tile id="841">
  <image width="79" height="99" source="../graphics/IIP - Outlined/Props/frameLargePink_b.png"/>
 </tile>
 <tile id="842">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumBlue_a.png"/>
 </tile>
 <tile id="843">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumBlue_b.png"/>
 </tile>
 <tile id="844">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumGreen_a.png"/>
 </tile>
 <tile id="845">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumGreen_b.png"/>
 </tile>
 <tile id="846">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumOrange_a.png"/>
 </tile>
 <tile id="847">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumOrange_b.png"/>
 </tile>
 <tile id="848">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumPink_a.png"/>
 </tile>
 <tile id="849">
  <image width="79" height="83" source="../graphics/IIP - Outlined/Props/frameMediumPink_b.png"/>
 </tile>
 <tile id="850">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallBlue_a.png"/>
 </tile>
 <tile id="851">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallBlue_b.png"/>
 </tile>
 <tile id="852">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallGreen_a.png"/>
 </tile>
 <tile id="853">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallGreen_b.png"/>
 </tile>
 <tile id="854">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallOrange_a.png"/>
 </tile>
 <tile id="855">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallOrange_b.png"/>
 </tile>
 <tile id="856">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallPink_a.png"/>
 </tile>
 <tile id="857">
  <image width="55" height="63" source="../graphics/IIP - Outlined/Props/frameSmallPink_b.png"/>
 </tile>
 <tile id="858">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/kitchenDrawerGray_a.png"/>
 </tile>
 <tile id="859">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/kitchenDrawerGray_b.png"/>
 </tile>
 <tile id="860">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/kitchenDrawerGreen_a.png"/>
 </tile>
 <tile id="861">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/kitchenDrawerGreen_b.png"/>
 </tile>
 <tile id="862">
  <image width="111" height="99" source="../graphics/IIP - Outlined/Props/kitchenSinkGray_a.png"/>
 </tile>
 <tile id="863">
  <image width="111" height="99" source="../graphics/IIP - Outlined/Props/kitchenSinkGray_b.png"/>
 </tile>
 <tile id="864">
  <image width="111" height="99" source="../graphics/IIP - Outlined/Props/kitchenSinkGreen_a.png"/>
 </tile>
 <tile id="865">
  <image width="111" height="99" source="../graphics/IIP - Outlined/Props/kitchenSinkGreen_b.png"/>
 </tile>
 <tile id="866">
  <image width="42" height="42" source="../graphics/IIP - Outlined/Props/laptop_a.png"/>
 </tile>
 <tile id="867">
  <image width="42" height="42" source="../graphics/IIP - Outlined/Props/laptop_b.png"/>
 </tile>
 <tile id="868">
  <image width="103" height="183" source="../graphics/IIP - Outlined/Props/refrigeratorBlack_a.png"/>
 </tile>
 <tile id="869">
  <image width="103" height="183" source="../graphics/IIP - Outlined/Props/refrigeratorBlack_b.png"/>
 </tile>
 <tile id="870">
  <image width="103" height="183" source="../graphics/IIP - Outlined/Props/refrigeratorWhite_a.png"/>
 </tile>
 <tile id="871">
  <image width="103" height="183" source="../graphics/IIP - Outlined/Props/refrigeratorWhite_b.png"/>
 </tile>
 <tile id="872">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeBlue.png"/>
 </tile>
 <tile id="873">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeBlueDamaged.png"/>
 </tile>
 <tile id="874">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeBrown.png"/>
 </tile>
 <tile id="875">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeBrownDamaged.png"/>
 </tile>
 <tile id="876">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeGreen.png"/>
 </tile>
 <tile id="877">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeGreenDamaged.png"/>
 </tile>
 <tile id="878">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeOlive.png"/>
 </tile>
 <tile id="879">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeOliveDamaged.png"/>
 </tile>
 <tile id="880">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargePurple.png"/>
 </tile>
 <tile id="881">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargePurpleDamaged.png"/>
 </tile>
 <tile id="882">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeRed.png"/>
 </tile>
 <tile id="883">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeRedDamaged.png"/>
 </tile>
 <tile id="884">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeWhite.png"/>
 </tile>
 <tile id="885">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeWhiteDamaged.png"/>
 </tile>
 <tile id="886">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeYellow.png"/>
 </tile>
 <tile id="887">
  <image width="263" height="135" source="../graphics/IIP - Outlined/Props/rugLargeYellowDamaged.png"/>
 </tile>
 <tile id="888">
  <image width="103" height="55" source="../graphics/IIP - Outlined/Props/rugSmallGreen.png"/>
 </tile>
 <tile id="889">
  <image width="103" height="55" source="../graphics/IIP - Outlined/Props/rugSmallOlive.png"/>
 </tile>
 <tile id="890">
  <image width="103" height="55" source="../graphics/IIP - Outlined/Props/rugSmallPurple.png"/>
 </tile>
 <tile id="891">
  <image width="103" height="55" source="../graphics/IIP - Outlined/Props/rugSmallRed.png"/>
 </tile>
 <tile id="892">
  <image width="103" height="55" source="../graphics/IIP - Outlined/Props/rugSmallTeal.png"/>
 </tile>
 <tile id="893">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/stoveGray_a.png"/>
 </tile>
 <tile id="894">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/stoveGray_b.png"/>
 </tile>
 <tile id="895">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/stoveGreen_a.png"/>
 </tile>
 <tile id="896">
  <image width="95" height="91" source="../graphics/IIP - Outlined/Props/stoveGreen_b.png"/>
 </tile>
 <tile id="897">
  <image width="47" height="43" source="../graphics/IIP - Outlined/Props/toaster_a.png"/>
 </tile>
 <tile id="898">
  <image width="47" height="43" source="../graphics/IIP - Outlined/Props/toaster_b.png"/>
 </tile>
 <tile id="899">
  <image width="63" height="79" source="../graphics/IIP - Outlined/Props/toilet_a.png"/>
 </tile>
 <tile id="900">
  <image width="63" height="79" source="../graphics/IIP - Outlined/Props/toilet_b.png"/>
 </tile>
 <tile id="901">
  <image width="63" height="79" source="../graphics/IIP - Outlined/Props/toiletDamaged_a.png"/>
 </tile>
 <tile id="902">
  <image width="63" height="79" source="../graphics/IIP - Outlined/Props/toiletDamaged_b.png"/>
 </tile>
 <tile id="903">
  <image width="79" height="89" source="../graphics/IIP - Outlined/Props/tv_a.png"/>
 </tile>
 <tile id="904">
  <image width="79" height="89" source="../graphics/IIP - Outlined/Props/tv_b.png"/>
 </tile>
 <tile id="905">
  <image width="71" height="71" source="../graphics/IIP - Outlined/Props/bathsink_a.png"/>
 </tile>
 <tile id="906">
  <image width="71" height="71" source="../graphics/IIP - Outlined/Props/bathSink_b.png"/>
 </tile>
 <tile id="907">
  <image width="71" height="71" source="../graphics/IIP - Outlined/Props/bathsinkDamaged_a.png"/>
 </tile>
 <tile id="908">
  <image width="71" height="71" source="../graphics/IIP - Outlined/Props/bathsinkDamaged_b.png"/>
 </tile>
 <tile id="909">
  <image width="199" height="143" source="../graphics/IIP - Outlined/Props/bathtub_a.png"/>
 </tile>
 <tile id="910">
  <image width="199" height="143" source="../graphics/IIP - Outlined/Props/bathtub_b.png"/>
 </tile>
 <tile id="911">
  <image width="199" height="143" source="../graphics/IIP - Outlined/Props/bathtubDamaged_a.png"/>
 </tile>
 <tile id="912">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlue_a.png"/>
 </tile>
 <tile id="913">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlue_b.png"/>
 </tile>
 <tile id="914">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueDoor_a.png"/>
 </tile>
 <tile id="915">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueDoor_b.png"/>
 </tile>
 <tile id="916">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueDoorDamaged_a.png"/>
 </tile>
 <tile id="917">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueDoorDamaged_b.png"/>
 </tile>
 <tile id="918">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueNodoor_a.png"/>
 </tile>
 <tile id="919">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueNodoor_b.png"/>
 </tile>
 <tile id="920">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueNodoorDamaged_a.png"/>
 </tile>
 <tile id="921">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueNodoorDamaged_b.png"/>
 </tile>
 <tile id="922">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueWindow_a.png"/>
 </tile>
 <tile id="923">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueWindow_b.png"/>
 </tile>
 <tile id="924">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueWindowDamaged_a.png"/>
 </tile>
 <tile id="925">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallBlueWindowDamaged_b.png"/>
 </tile>
 <tile id="926">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreen_a.png"/>
 </tile>
 <tile id="927">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreen_b.png"/>
 </tile>
 <tile id="928">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenDoor_a.png"/>
 </tile>
 <tile id="929">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenDoor_b.png"/>
 </tile>
 <tile id="930">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenDoorDamaged_a.png"/>
 </tile>
 <tile id="931">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenDoorDamaged_b.png"/>
 </tile>
 <tile id="932">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenNodoor_a.png"/>
 </tile>
 <tile id="933">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenNodoor_b.png"/>
 </tile>
 <tile id="934">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenNodoorDamaged_a.png"/>
 </tile>
 <tile id="935">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenNodoorDamaged_b.png"/>
 </tile>
 <tile id="936">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenWindow_a.png"/>
 </tile>
 <tile id="937">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenWindow_b.png"/>
 </tile>
 <tile id="938">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenWindowDamaged_a.png"/>
 </tile>
 <tile id="939">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallGreenWindowDamaged_b.png"/>
 </tile>
 <tile id="940">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRed_a.png"/>
 </tile>
 <tile id="941">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRed_b.png"/>
 </tile>
 <tile id="942">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedDoor_a.png"/>
 </tile>
 <tile id="943">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedDoor_b.png"/>
 </tile>
 <tile id="944">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedDoorDamaged_a.png"/>
 </tile>
 <tile id="945">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedDoorDamaged_b.png"/>
 </tile>
 <tile id="946">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedNodoor_a.png"/>
 </tile>
 <tile id="947">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedNodoor_b.png"/>
 </tile>
 <tile id="948">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedNodoorDamaged_a.png"/>
 </tile>
 <tile id="949">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedNodoorDamaged_b.png"/>
 </tile>
 <tile id="950">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedWindow_a.png"/>
 </tile>
 <tile id="951">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedWindow_b.png"/>
 </tile>
 <tile id="952">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedWindowDamaged_a.png"/>
 </tile>
 <tile id="953">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallRedWindowDamaged_b.png"/>
 </tile>
 <tile id="954">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTan_a.png"/>
 </tile>
 <tile id="955">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTan_b.png"/>
 </tile>
 <tile id="956">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanDoor_a.png"/>
 </tile>
 <tile id="957">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanDoor_b.png"/>
 </tile>
 <tile id="958">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanDoorDamaged_a.png"/>
 </tile>
 <tile id="959">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanDoorDamaged_b.png"/>
 </tile>
 <tile id="960">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanNodoor_a.png"/>
 </tile>
 <tile id="961">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanNodoor_b.png"/>
 </tile>
 <tile id="962">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanNodoorDamaged_a.png"/>
 </tile>
 <tile id="963">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanNodoorDamaged_b.png"/>
 </tile>
 <tile id="964">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanWindow_a.png"/>
 </tile>
 <tile id="965">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanWindow_b.png"/>
 </tile>
 <tile id="966">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanWindowDamaged_a.png"/>
 </tile>
 <tile id="967">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallTanWindowDamaged_b.png"/>
 </tile>
 <tile id="968">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYelloDoor_b.png"/>
 </tile>
 <tile id="969">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellow_a.png"/>
 </tile>
 <tile id="970">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellow_b.png"/>
 </tile>
 <tile id="971">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowDoor_a.png"/>
 </tile>
 <tile id="972">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowDoorDamaged_a.png"/>
 </tile>
 <tile id="973">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowDoorDamaged_b.png"/>
 </tile>
 <tile id="974">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowNodoor_a.png"/>
 </tile>
 <tile id="975">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowNodoor_b.png"/>
 </tile>
 <tile id="976">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowNodoorDamaged_a.png"/>
 </tile>
 <tile id="977">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowNodoorDamaged_b.png"/>
 </tile>
 <tile id="978">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowWindow_a.png"/>
 </tile>
 <tile id="979">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowWindow_b.png"/>
 </tile>
 <tile id="980">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowWindowDamaged_a.png"/>
 </tile>
 <tile id="981">
  <image width="287" height="299" source="../graphics/IIP - Outlined/walls/wallYellowWindowDamaged_b.png"/>
 </tile>
 <tile id="982">
  <image width="287" height="171" source="../graphics/IIP - Outlined/walls/seamBlack_a.png"/>
 </tile>
 <tile id="983">
  <image width="287" height="171" source="../graphics/IIP - Outlined/walls/seamBlack_b.png"/>
 </tile>
 <tile id="984">
  <image width="55" height="183" source="../graphics/IIP - Outlined/walls/seamBlack_c.png"/>
 </tile>
 <tile id="985">
  <image width="287" height="171" source="../graphics/IIP - Outlined/walls/seamGray_a.png"/>
 </tile>
 <tile id="986">
  <image width="287" height="171" source="../graphics/IIP - Outlined/walls/seamGray_b.png"/>
 </tile>
 <tile id="987">
  <image width="55" height="183" source="../graphics/IIP - Outlined/walls/seamGray_c.png"/>
 </tile>
 <tile id="988">
  <image width="1000" height="750" source="../graphics/hjm-chair+table/hjm-chair+table.png"/>
 </tile>
 <tile id="989">
  <image width="639" height="531" source="../graphics/hjm-cabinet/hjm-cabinet.png"/>
 </tile>
 <tile id="990">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Complete room.png"/>
 </tile>
 <tile id="991">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Desk 1.png"/>
 </tile>
 <tile id="992">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Desk 2.png"/>
 </tile>
 <tile id="993">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Lamp.png"/>
 </tile>
 <tile id="994">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Mirror 1.png"/>
 </tile>
 <tile id="995">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Mirror 2.png"/>
 </tile>
 <tile id="996">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Room estructure.png"/>
 </tile>
 <tile id="997">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/shelving 1.png"/>
 </tile>
 <tile id="998">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/shelving 2.png"/>
 </tile>
 <tile id="999">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Sprite 1.png"/>
 </tile>
 <tile id="1000">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/wall shelving 1.png"/>
 </tile>
 <tile id="1001">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/bed 1.png"/>
 </tile>
 <tile id="1002">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/bed 2.png"/>
 </tile>
 <tile id="1003">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Books.png"/>
 </tile>
 <tile id="1004">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Chair 1.png"/>
 </tile>
 <tile id="1005">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Chair 2.png"/>
 </tile>
 <tile id="1006">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Closet 1.png"/>
 </tile>
 <tile id="1007">
  <image width="1080" height="1080" source="../graphics/Free isometric voxel room/PNGs/Closet 2.png"/>
 </tile>
</tileset>
