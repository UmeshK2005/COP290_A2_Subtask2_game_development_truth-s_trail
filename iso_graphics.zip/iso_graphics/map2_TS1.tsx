<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TS1" tilewidth="522" tileheight="311" tilecount="28" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorCheckeredWhite.png"/>
 </tile>
 <tile id="1">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorCheckeredWhiteDamaged.png"/>
 </tile>
 <tile id="2">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorGray.png"/>
 </tile>
 <tile id="3">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorGrayDamaged.png"/>
 </tile>
 <tile id="4">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorOlive.png"/>
 </tile>
 <tile id="5">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorOliveDamaged.png"/>
 </tile>
 <tile id="6">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorPurple.png"/>
 </tile>
 <tile id="7">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorPurpleDamaged.png"/>
 </tile>
 <tile id="8">
  <image width="522" height="282" source="../graphics/IIP - Outlined/floors/floorTeal.png"/>
 </tile>
 <tile id="9">
  <image width="521" height="283" source="../graphics/IIP - Outlined/floors/floorTealDamaged.png"/>
 </tile>
 <tile id="10">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorWhite.png"/>
 </tile>
 <tile id="11">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorWhiteDamaged.png"/>
 </tile>
 <tile id="12">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorYellow.png"/>
 </tile>
 <tile id="13">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorYellowDamaged.png"/>
 </tile>
 <tile id="14">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsBrown_a.png"/>
 </tile>
 <tile id="15">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsBrown_b.png"/>
 </tile>
 <tile id="16">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsBrownDamaged_a.png"/>
 </tile>
 <tile id="17">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsBrownDamaged_b.png"/>
 </tile>
 <tile id="18">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsGray_a.png"/>
 </tile>
 <tile id="19">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsGray_b.png"/>
 </tile>
 <tile id="20">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsGrayDamaged_a.png"/>
 </tile>
 <tile id="21">
  <image width="263" height="311" source="../graphics/IIP - Outlined/floors/stairsGrayDamaged_b.png"/>
 </tile>
 <tile id="22">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorBlue.png"/>
 </tile>
 <tile id="23">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorBlueDamaged.png"/>
 </tile>
 <tile id="24">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorBrown.png"/>
 </tile>
 <tile id="25">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorBrownDamaged.png"/>
 </tile>
 <tile id="26">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorCheckeredBlue.png"/>
 </tile>
 <tile id="27">
  <image width="519" height="287" source="../graphics/IIP - Outlined/floors/floorCheckeredBlueDamaged.png"/>
 </tile>
</tileset>
