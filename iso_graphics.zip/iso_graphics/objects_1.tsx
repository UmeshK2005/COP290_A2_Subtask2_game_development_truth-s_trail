<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects_1" tilewidth="3000" tileheight="3000" tilecount="11" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="96" height="143" source="../graphics/Sprites/Sprites/Temple/Decoration/statue_cat_NW.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="64" source="../graphics/Sprites/Sprites/Temple/Raised/temple-stairs-blue.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="../graphics/Sprites/Sprites/Temple/Raised/temple-sliced_42.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="../graphics/Sprites/Sprites/Temple/Raised/temple-sliced_41.png"/>
 </tile>
 <tile id="4">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_NE.png"/>
 </tile>
 <tile id="5">
  <image width="43" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_NW.png"/>
 </tile>
 <tile id="6">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_SW.png"/>
 </tile>
 <tile id="7">
  <image width="44" height="107" source="../graphics/kenney_furniturePack/Isometric/doorwayFront_SE.png"/>
 </tile>
 <tile id="8">
  <image width="3000" height="3000" source="../useful_images/key.png"/>
 </tile>
 <tile id="9">
  <image width="748" height="705" source="../useful_images/mansion_map.png"/>
 </tile>
 <tile id="11">
  <image width="2109" height="780" source="../images/Picture1.png"/>
 </tile>
</tileset>
