<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="floorPurpleDamaged" tilewidth="64" tileheight="32" tilecount="64" columns="8">
 <image source="../graphics/IIP - Outlined/floors/floorPurpleDamaged.png" width="519" height="287"/>
</tileset>
