import pygame, sys
from pygame.math import Vector2 as vector

class settings:
    ANIMATION_SPEED =15
    WINDOW_WIDTH, WINDOW_HEIGHT = 1280, 720
    TILE_SIZE = 30
	
