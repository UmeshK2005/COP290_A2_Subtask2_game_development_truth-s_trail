<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="500" tileheight="497" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="99" height="168" source="../graphics/objects/Screenshot_2024-04-03_205822-removebg-preview.png"/>
 </tile>
 <tile id="1">
  <image width="244" height="277" source="../graphics/objects/Screenshot_2024-04-03_215536-removebg-preview (1).png"/>
 </tile>
 <tile id="2">
  <image width="500" height="497" source="../graphics/objects/Screenshot_2024-04-03_203804-removebg-preview.png"/>
 </tile>
 <tile id="3">
  <image width="98" height="174" source="../graphics/objects/Screenshot_2024-04-03_205745-removebg-preview.png"/>
 </tile>
 <tile id="4">
  <image width="99" height="165" source="../graphics/objects/Screenshot_2024-04-03_205801-removebg-preview.png"/>
 </tile>
</tileset>
