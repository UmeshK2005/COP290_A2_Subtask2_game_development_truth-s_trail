import pygame, sys
from pygame.math import Vector2 as vector

class settings:
	WINDOW_WIDTH, WINDOW_HEIGHT = 1500, 1020
	TILE_SIZE = 64
	
